package com.example.audio

import java.io.File
import java.io.FileInputStream
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Pure-Kotlin OpenAI Whisper acoustic frontend:
 * - 16 kHz mono float32 normalization
 * - 400-point Hann-windowed STFT with 160-sample hop (3000 frames for 30s)
 * - Slaney-normalized 80-bin Log-Mel Spectrogram [80, 3000]
 */
object WhisperAudioProcessor {
    const val SAMPLE_RATE = 16000
    const val N_FFT = 400
    const val HOP_LENGTH = 160
    const val N_MELS = 80
    const val CHUNK_SECONDS = 30
    const val N_SAMPLES = SAMPLE_RATE * CHUNK_SECONDS // 480,000
    const val N_FRAMES = 3000
    private const val N_FREQS = N_FFT / 2 + 1 // 201

    private val hannWindow: FloatArray by lazy {
        FloatArray(N_FFT) { n ->
            (0.5 * (1.0 - cos(2.0 * PI * n / N_FFT))).toFloat()
        }
    }

    // Precomputed 400-point DFT cos & sin tables for bins 0..200
    private val cosTable: FloatArray by lazy {
        FloatArray(N_FREQS * N_FFT).also { table ->
            for (k in 0 until N_FREQS) {
                val base = k * N_FFT
                val freq = 2.0 * PI * k / N_FFT
                for (n in 0 until N_FFT) {
                    table[base + n] = cos(freq * n).toFloat()
                }
            }
        }
    }

    private val sinTable: FloatArray by lazy {
        FloatArray(N_FREQS * N_FFT).also { table ->
            for (k in 0 until N_FREQS) {
                val base = k * N_FFT
                val freq = 2.0 * PI * k / N_FFT
                for (n in 0 until N_FFT) {
                    table[base + n] = -sin(freq * n).toFloat()
                }
            }
        }
    }

    // Slaney-style 80-band Mel filterbank [N_MELS x N_FREQS] matching librosa / OpenAI Whisper
    private val melFilters: FloatArray by lazy { buildSlaneyMelFilterbank() }

    fun readPcm16File(path: String): ShortArray {
        val file = File(path)
        val bytes = FileInputStream(file).use { it.readBytes() }
        val count = bytes.size / 2
        val shorts = ShortArray(count)
        for (i in 0 until count) {
            val lo = bytes[i * 2].toInt() and 0xFF
            val hi = bytes[i * 2 + 1].toInt()
            shorts[i] = ((hi shl 8) or lo).toShort()
        }
        return shorts
    }

    fun pcm16ToPaddedFloat32(pcm16: ShortArray): FloatArray {
        val out = FloatArray(N_SAMPLES)
        val len = min(pcm16.size, N_SAMPLES)
        for (i in 0 until len) {
            out[i] = pcm16[i] / 32768.0f
        }
        return out
    }

    /**
     * Computes [N_MELS, N_FRAMES] row-major Log-Mel spectrogram normalized to Whisper's [-1, 1] range.
     */
    fun computeLogMelSpectrogram(pcm16: ShortArray): FloatArray {
        val samples = pcm16ToPaddedFloat32(pcm16)
        val melSpec = FloatArray(N_MELS * N_FRAMES)
        val pad = N_FFT / 2
        val frameSamples = FloatArray(N_FFT)
        val powerSpec = FloatArray(N_FREQS)

        var maxLogMel = -Float.MAX_VALUE

        for (frame in 0 until N_FRAMES) {
            val center = frame * HOP_LENGTH
            for (n in 0 until N_FFT) {
                val sampleIdx = center + n - pad
                val sample = when {
                    sampleIdx < 0 -> samples[-sampleIdx.coerceAtMost(samples.lastIndex)]
                    sampleIdx >= samples.size -> {
                        val reflected = 2 * samples.size - 2 - sampleIdx
                        if (reflected in samples.indices) samples[reflected] else 0f
                    }
                    else -> samples[sampleIdx]
                }
                frameSamples[n] = sample * hannWindow[n]
            }

            // Compute power spectrum for 201 bins
            for (k in 0 until N_FREQS) {
                val base = k * N_FFT
                var re = 0f
                var im = 0f
                for (n in 0 until N_FFT) {
                    val x = frameSamples[n]
                    re += x * cosTable[base + n]
                    im += x * sinTable[base + n]
                }
                powerSpec[k] = re * re + im * im
            }

            // Project onto 80 Mel bands
            for (m in 0 until N_MELS) {
                val melBase = m * N_FREQS
                var sum = 0f
                for (k in 0 until N_FREQS) {
                    val w = melFilters[melBase + k]
                    if (w != 0f) sum += w * powerSpec[k]
                }
                val logVal = log10(max(sum, 1e-10f))
                melSpec[m * N_FRAMES + frame] = logVal
                if (logVal > maxLogMel) maxLogMel = logVal
            }
        }

        val clampFloor = maxLogMel - 8.0f
        for (i in melSpec.indices) {
            val clamped = max(melSpec[i], clampFloor)
            melSpec[i] = (clamped + 4.0f) / 4.0f
        }
        return melSpec
    }

    private fun hzToMelSlaney(hz: Double): Double {
        val fSp = 200.0 / 3.0
        var mel = hz / fSp
        val minLogHz = 1000.0
        val minLogMel = minLogHz / fSp
        val logStep = ln(6.4) / 27.0
        if (hz >= minLogHz) {
            mel = minLogMel + ln(hz / minLogHz) / logStep
        }
        return mel
    }

    private fun melToHzSlaney(mel: Double): Double {
        val fSp = 200.0 / 3.0
        var hz = fSp * mel
        val minLogHz = 1000.0
        val minLogMel = minLogHz / fSp
        val logStep = ln(6.4) / 27.0
        if (mel >= minLogMel) {
            hz = minLogHz * kotlin.math.exp(logStep * (mel - minLogMel))
        }
        return hz
    }

    private fun buildSlaneyMelFilterbank(): FloatArray {
        val weights = FloatArray(N_MELS * N_FREQS)
        val fftFreqs = DoubleArray(N_FREQS) { k ->
            k.toDouble() * (SAMPLE_RATE / 2.0) / (N_FREQS - 1)
        }
        val minMel = hzToMelSlaney(0.0)
        val maxMel = hzToMelSlaney(8000.0)
        val melPoints = DoubleArray(N_MELS + 2) { i ->
            melToHzSlaney(minMel + (maxMel - minMel) * i / (N_MELS + 1))
        }

        for (m in 0 until N_MELS) {
            val fLeft = melPoints[m]
            val fCenter = melPoints[m + 1]
            val fRight = melPoints[m + 2]
            val enorm = 2.0 / (fRight - fLeft)

            for (k in 0 until N_FREQS) {
                val f = fftFreqs[k]
                val w = when {
                    f >= fLeft && f <= fCenter && fCenter > fLeft -> (f - fLeft) / (fCenter - fLeft)
                    f > fCenter && f <= fRight && fRight > fCenter -> (fRight - f) / (fRight - fCenter)
                    else -> 0.0
                }
                weights[m * N_FREQS + k] = (w * enorm).toFloat()
            }
        }
        return weights
    }
}
