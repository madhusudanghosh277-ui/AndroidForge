package com.example.data.repo

import android.content.Context
import com.example.data.db.AudioChunkEntity
import com.example.data.db.ChunkStatus
import com.example.data.db.EchoScribeDao
import com.example.data.db.TranscriptionJobEntity
import com.example.whisper.TranscriptStitcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class TranscriptionRepository(
    private val context: Context,
    private val dao: EchoScribeDao,
) {
    val jobs: Flow<List<TranscriptionJobEntity>> = dao.observeJobs()
    val activeJob: Flow<TranscriptionJobEntity?> = dao.observeActiveJob()

    fun observeJob(jobId: String): Flow<TranscriptionJobEntity?> = dao.observeJob(jobId)

    fun observeChunks(jobId: String): Flow<List<AudioChunkEntity>> = dao.observeChunksForJob(jobId)

    suspend fun getJob(jobId: String): TranscriptionJobEntity? = dao.getJob(jobId)

    suspend fun getChunks(jobId: String): List<AudioChunkEntity> = dao.getChunksForJob(jobId)

    suspend fun upsertJob(job: TranscriptionJobEntity) = dao.upsertJob(job)

    suspend fun upsertChunks(chunks: List<AudioChunkEntity>) = dao.upsertChunks(chunks)

    suspend fun upsertChunk(chunk: AudioChunkEntity) = dao.upsertChunk(chunk)

    suspend fun updateChunkTextAndRestitch(chunkId: String, newText: String) {
        val chunk = dao.getChunkById(chunkId) ?: return
        dao.upsertChunk(
            chunk.copy(
                rawText = newText,
                status = ChunkStatus.COMPLETED.name,
                errorMessage = null,
            )
        )
        restitchJob(chunk.jobId)
    }

    suspend fun restitchJob(jobId: String) {
        val job = dao.getJob(jobId) ?: return
        val chunks = dao.getChunksForJob(jobId)
        val stitched = TranscriptStitcher.stitchChunks(chunks)
        val completedCount = chunks.count { it.status == ChunkStatus.COMPLETED.name }
        dao.updateJob(
            job.copy(
                completedChunks = completedCount,
                stitchedTranscript = stitched,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    suspend fun deleteJob(jobId: String) = withContext(Dispatchers.IO) {
        dao.deleteJob(jobId)
        File(context.filesDir, "jobs/$jobId").deleteRecursively()
    }

    suspend fun buildExportContent(jobId: String, format: String): String {
        val job = dao.getJob(jobId) ?: return ""
        val chunks = dao.getChunksForJob(jobId)
        return when (format.lowercase()) {
            "srt" -> TranscriptStitcher.formatAsSrt(chunks)
            "vtt" -> TranscriptStitcher.formatAsVtt(chunks)
            "json" -> {
                val root = JSONObject().apply {
                    put("title", job.title)
                    put("sourceFile", job.sourceFileName)
                    put("durationMs", job.totalDurationMs)
                    put("model", job.modelName)
                    put("language", job.languageCode)
                    put("chunkDurationSec", job.chunkDurationSec)
                    put("overlapSec", job.overlapSec)
                    put("transcript", job.stitchedTranscript)
                    val arr = JSONArray()
                    chunks.forEach { c ->
                        arr.put(
                            JSONObject().apply {
                                put("index", c.chunkIndex)
                                put("startMs", c.startMs)
                                put("endMs", c.endMs)
                                put("inferenceMs", c.inferenceMs)
                                put("text", c.rawText)
                            }
                        )
                    }
                    put("chunks", arr)
                }
                root.toString(2)
            }
            else -> job.stitchedTranscript
        }
    }
}
