package com.example.whisper

import com.example.data.db.ModelFormat
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class InspectedModelInfo(
    val format: ModelFormat,
    val sizeTier: String,
    val multilingual: Boolean,
    val inputShapeSummary: String,
    val warningMessage: String? = null,
)

object ModelInspector {
    fun inspect(file: File, originalFileName: String): InspectedModelInfo {
        val lower = originalFileName.lowercase()
        val sizeBytes = file.length()
        val sizeTier = inferSizeTier(lower, sizeBytes)
        val multilingual = !lower.contains(".en")

        if (lower.endsWith(".tflite")) {
            return InspectedModelInfo(
                format = ModelFormat.TFLITE,
                sizeTier = sizeTier,
                multilingual = multilingual,
                inputShapeSummary = "LiteRT FlatBuffer (.tflite) • CPU Accelerated",
            )
        }

        if (lower.endsWith(".onnx")) {
            return InspectedModelInfo(
                format = ModelFormat.ONNX_SINGLE,
                sizeTier = sizeTier,
                multilingual = multilingual,
                inputShapeSummary = "ONNX Graph (.onnx) • CPU ExecutionProvider",
            )
        }

        // Check GGML / GGUF magic bytes for .bin files
        val magic = readMagicInt(file)
        if (magic == 0x67676d6c || magic == 0x46554747 || lower.endsWith(".bin") || lower.endsWith(".gguf")) {
            val ggmlSummary = parseGgmlHeaderSummary(file)
            return InspectedModelInfo(
                format = ModelFormat.GGML_UNSUPPORTED_RUNTIME,
                sizeTier = sizeTier,
                multilingual = multilingual,
                inputShapeSummary = ggmlSummary,
                warningMessage = "GGML .bin inspected ($ggmlSummary). For CPU execution on all Android ABIs, import a .tflite or .onnx Whisper model.",
            )
        }

        return InspectedModelInfo(
            format = ModelFormat.TFLITE,
            sizeTier = sizeTier,
            multilingual = multilingual,
            inputShapeSummary = "Local Model (${formatSizeMb(sizeBytes)})",
        )
    }

    private fun inferSizeTier(lowerName: String, sizeBytes: Long): String {
        return when {
            lowerName.contains("tiny") -> "Tiny"
            lowerName.contains("base") -> "Base"
            lowerName.contains("small") -> "Small"
            lowerName.contains("medium") -> "Medium"
            lowerName.contains("large") -> "Large"
            sizeBytes < 65_000_000L -> "Tiny"
            sizeBytes < 140_000_000L -> "Base"
            sizeBytes < 350_000_000L -> "Small"
            else -> "Custom"
        }
    }

    private fun readMagicInt(file: File): Int {
        return runCatching {
            FileInputStream(file).use { fis ->
                val buf = ByteArray(4)
                if (fis.read(buf) == 4) {
                    ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).int
                } else 0
            }
        }.getOrDefault(0)
    }

    private fun parseGgmlHeaderSummary(file: File): String {
        return runCatching {
            FileInputStream(file).use { fis ->
                val buf = ByteArray(48)
                val read = fis.read(buf)
                if (read >= 44) {
                    val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                    val magic = bb.int
                    if (magic == 0x67676d6c) {
                        val nVocab = bb.int
                        val nAudioCtx = bb.int
                        val nAudioState = bb.int
                        val nAudioHead = bb.int
                        val nAudioLayer = bb.int
                        return@use "GGML • ${nAudioLayer}L/${nAudioState}d • vocab=$nVocab"
                    }
                }
                "GGML Binary (${formatSizeMb(file.length())})"
            }
        }.getOrDefault("GGML Binary")
    }

    fun formatSizeMb(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 100) "%.0f MB".format(mb) else "%.1f MB".format(mb)
    }
}
