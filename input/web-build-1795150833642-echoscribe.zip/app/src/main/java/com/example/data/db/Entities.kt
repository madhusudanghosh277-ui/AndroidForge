package com.example.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class ModelFormat {
    TFLITE,
    ONNX_SINGLE,
    ONNX_ENCODER_DECODER,
    GGML_UNSUPPORTED_RUNTIME
}

enum class JobStatus {
    PREPARING,
    SPLITTING,
    TRANSCRIBING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

enum class ChunkStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}

@Entity(tableName = "imported_models")
data class ImportedModelEntity(
    @PrimaryKey val id: String,
    val name: String,
    val fileName: String,
    val format: String, // ModelFormat.name
    val primaryPath: String,
    val decoderPath: String? = null,
    val vocabPath: String? = null,
    val vocabFileName: String? = null,
    val fileSizeBytes: Long,
    val sizeTier: String, // Tiny, Base, Small, Medium, Custom
    val multilingual: Boolean,
    val inputShapeSummary: String,
    val isSelected: Boolean = false,
    val importedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "transcription_jobs")
data class TranscriptionJobEntity(
    @PrimaryKey val id: String,
    val title: String,
    val sourceFileName: String,
    val sourceUriString: String,
    val totalDurationMs: Long,
    val sampleRateHz: Int,
    val chunkDurationSec: Int,
    val overlapSec: Int,
    val totalChunks: Int,
    val completedChunks: Int,
    val status: String, // JobStatus.name
    val modelId: String,
    val modelName: String,
    val languageCode: String,
    val translateToEnglish: Boolean,
    val cpuThreads: Int,
    val processingTimeMs: Long = 0L,
    val stitchedTranscript: String = "",
    val errorMessage: String? = null,
    val waveformPeaksCsv: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "audio_chunks",
    foreignKeys = [
        ForeignKey(
            entity = TranscriptionJobEntity::class,
            parentColumns = ["id"],
            childColumns = ["jobId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("jobId")]
)
data class AudioChunkEntity(
    @PrimaryKey val id: String,
    val jobId: String,
    val chunkIndex: Int,
    val startMs: Long,
    val endMs: Long,
    val pcmFilePath: String,
    val status: String, // ChunkStatus.name
    val rawText: String = "",
    val stitchedText: String = "",
    val inferenceMs: Long = 0L,
    val peaksCsv: String = "",
    val errorMessage: String? = null,
)
