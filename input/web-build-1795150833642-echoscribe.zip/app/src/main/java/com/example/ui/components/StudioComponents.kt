package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.db.AudioChunkEntity
import com.example.data.db.ChunkStatus
import com.example.data.db.ImportedModelEntity
import com.example.data.db.ModelFormat
import com.example.whisper.ModelInspector
import java.util.Locale

object StudioFormatters {
    fun formatDurationMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatCompactDuration(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return when {
            hours > 0L -> "${hours}h ${minutes}m"
            minutes > 0L -> "${minutes}m ${seconds}s"
            else -> "${seconds}s"
        }
    }

    fun formatFormatBadge(formatStr: String): String {
        return when (formatStr) {
            ModelFormat.TFLITE.name -> "TFLITE"
            ModelFormat.ONNX_SINGLE.name -> "ONNX"
            ModelFormat.ONNX_ENCODER_DECODER.name -> "ONNX E+D"
            ModelFormat.GGML_UNSUPPORTED_RUNTIME.name -> "GGML"
            else -> "MODEL"
        }
    }

    fun parsePeaks(csv: String): List<Float> {
        if (csv.isBlank()) return emptyList()
        return csv.split(',').mapNotNull { it.toFloatOrNull()?.coerceIn(0.04f, 1.0f) }
    }
}

@Composable
fun ActiveModelStatusPill(
    selectedModel: ImportedModelEntity?,
    cpuThreads: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val hasValidModel = selectedModel != null &&
        selectedModel.format != ModelFormat.GGML_UNSUPPORTED_RUNTIME.name

    val containerColor = if (hasValidModel) {
        MaterialTheme.colorScheme.surface
    } else {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    }
    val borderColor = if (hasValidModel) {
        MaterialTheme.colorScheme.outlineVariant
    } else {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("active_model_status_pill"),
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(
                        if (hasValidModel) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.primaryContainer
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (hasValidModel) Icons.Rounded.Memory else Icons.Rounded.UploadFile,
                    contentDescription = "Active local Whisper model",
                    tint = if (hasValidModel) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp),
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                if (hasValidModel && selectedModel != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text(
                            text = selectedModel.name,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        TelemetryBadge(
                            text = StudioFormatters.formatFormatBadge(selectedModel.format),
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    val vocabNote = if (selectedModel.vocabPath != null) "Vocab ready" else "No vocab attached"
                    Text(
                        text = "${selectedModel.sizeTier} • ${ModelInspector.formatSizeMb(selectedModel.fileSizeBytes)} • ${cpuThreads}T CPU • $vocabNote",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                } else {
                    Text(
                        text = "No Whisper Model Loaded",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                    Text(
                        text = "Tap to import a local .tflite or .onnx model from files",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                    )
                }
            }

            if (hasValidModel && selectedModel?.vocabPath == null) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = "Optional vocabulary file not attached",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
fun TelemetryBadge(
    text: String,
    containerColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    contentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = containerColor,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
            color = contentColor,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            maxLines = 1,
        )
    }
}

@Composable
fun WaveformTimelineCanvas(
    peaks: List<Float>,
    progressFraction: Float,
    modifier: Modifier = Modifier,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    completedColor: Color = MaterialTheme.colorScheme.secondary,
    inactiveColor: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
) {
    val bars = if (peaks.isEmpty()) {
        List(44) { idx -> 0.18f + 0.55f * kotlin.math.abs(kotlin.math.sin(idx * 0.45f)) }
    } else {
        peaks
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(42.dp)
    ) {
        val count = bars.size.coerceAtLeast(1)
        val gap = 3.dp.toPx()
        val barWidth = ((size.width - gap * (count - 1)) / count).coerceAtLeast(2.dp.toPx())
        val centerY = size.height / 2f

        bars.forEachIndexed { index, amp ->
            val fraction = (index + 0.5f) / count.toFloat()
            val color = when {
                fraction < progressFraction -> completedColor
                fraction <= (progressFraction + 0.03f) && progressFraction > 0f && progressFraction < 1f -> activeColor
                else -> inactiveColor
            }
            val barH = (size.height * amp.coerceIn(0.08f, 1f)).coerceAtLeast(4.dp.toPx())
            val left = index * (barWidth + gap)
            drawRoundRect(
                color = color,
                topLeft = Offset(left, centerY - barH / 2f),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
            )
        }
    }
}

@Composable
fun ChunkProgressStrip(
    chunks: List<AudioChunkEntity>,
    modifier: Modifier = Modifier,
) {
    if (chunks.isEmpty()) return
    val visibleChunks = if (chunks.size <= 64) chunks else {
        val step = chunks.size / 64f
        List(64) { i -> chunks[(i * step).toInt().coerceIn(0, chunks.lastIndex)] }
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        visibleChunks.forEach { chunk ->
            val targetColor = when (chunk.status) {
                ChunkStatus.COMPLETED.name -> MaterialTheme.colorScheme.secondary
                ChunkStatus.PROCESSING.name -> MaterialTheme.colorScheme.primary
                ChunkStatus.FAILED.name -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
            val animatedColor by animateColorAsState(targetValue = targetColor, label = "chunk_color")
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(animatedColor)
            )
        }
    }
}
