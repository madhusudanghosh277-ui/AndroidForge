package com.example.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class AudioInspection(
    val displayName: String,
    val fileSizeBytes: Long,
    val durationMs: Long,
    val sampleRateHz: Int,
    val channels: Int,
    val mimeType: String,
)

data class SplitChunkInfo(
    val chunkIndex: Int,
    val startMs: Long,
    val endMs: Long,
    val pcmFilePath: String,
    val sampleCount: Int,
    val peaksCsv: String,
)

data class SplitResult(
    val durationMs: Long,
    val chunks: List<SplitChunkInfo>,
    val globalPeaksCsv: String,
)

object AudioSplitter {
    const val TARGET_SAMPLE_RATE = 16000

    suspend fun inspectAudio(context: Context, uri: Uri): AudioInspection = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var displayName = "audio_input"
        var fileSize = 0L

        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
                    if (sizeIdx >= 0) fileSize = cursor.getLong(sizeIdx)
                }
            }

        val mimeType = resolver.getType(uri) ?: inferMimeType(displayName)
        var durationMs = 0L
        var sampleRate = 16000
        var channels = 1

        // Fast-path WAV header inspection
        if (displayName.endsWith(".wav", ignoreCase = true) || mimeType.contains("wav")) {
            val wavInfo = tryReadWavHeader(resolver.openInputStream(uri))
            if (wavInfo != null) {
                sampleRate = wavInfo.sampleRate
                channels = wavInfo.channels
                durationMs = wavInfo.durationMs
            }
        }

        if (durationMs <= 0L) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
                val sr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)
                    ?.toIntOrNull()
                if (sr != null && sr > 0) sampleRate = sr
            } catch (_: Exception) {
                // Fallback to MediaExtractor below
            } finally {
                runCatching { retriever.release() }
            }
        }

        if (durationMs <= 0L) {
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(context, uri, null)
                val audioTrack = findAudioTrack(extractor)
                if (audioTrack >= 0) {
                    val format = extractor.getTrackFormat(audioTrack)
                    if (format.containsKey(MediaFormat.KEY_DURATION)) {
                        durationMs = format.getLong(MediaFormat.KEY_DURATION) / 1000L
                    }
                    if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            } catch (_: Exception) {
            } finally {
                runCatching { extractor.release() }
            }
        }

        AudioInspection(
            displayName = displayName,
            fileSizeBytes = fileSize,
            durationMs = durationMs.coerceAtLeast(0L),
            sampleRateHz = sampleRate,
            channels = channels,
            mimeType = mimeType,
        )
    }

    suspend fun splitAudioToChunks(
        context: Context,
        uri: Uri,
        jobId: String,
        chunkDurationSec: Int,
        overlapSec: Int,
        vadSplitEnabled: Boolean,
        expectedDurationMs: Long,
        onProgress: (Float, Int) -> Unit,
    ): SplitResult = withContext(Dispatchers.IO) {
        val jobDir = File(context.filesDir, "jobs/$jobId").apply { mkdirs() }
        val chunkSamplesTarget = chunkDurationSec.coerceIn(10, 30) * TARGET_SAMPLE_RATE
        val overlapSamples = overlapSec.coerceIn(0, 5) * TARGET_SAMPLE_RATE
        val vadLookaheadSamples = if (vadSplitEnabled) (1.5f * TARGET_SAMPLE_RATE).toInt() else 0

        val writer = StreamingChunkWriter(
            jobDir = jobDir,
            chunkSamplesTarget = chunkSamplesTarget,
            overlapSamples = overlapSamples,
            vadSplitEnabled = vadSplitEnabled,
            vadLookaheadSamples = vadLookaheadSamples,
            expectedTotalSamples = (expectedDurationMs * TARGET_SAMPLE_RATE / 1000L).coerceAtLeast(1L),
            onProgress = onProgress,
        )

        val inspection = inspectAudio(context, uri)
        val isWav = inspection.displayName.endsWith(".wav", ignoreCase = true) ||
            inspection.mimeType.contains("wav")

        var decodedViaWav = false
        if (isWav) {
            decodedViaWav = tryDecodeWavStream(context, uri, writer)
        }
        if (!decodedViaWav) {
            decodeWithMediaCodec(context, uri, writer)
        }

        writer.finish()
    }

    private suspend fun tryDecodeWavStream(
        context: Context,
        uri: Uri,
        writer: StreamingChunkWriter,
    ): Boolean {
        val stream = context.contentResolver.openInputStream(uri) ?: return false
        return stream.use { rawIn ->
            val bis = BufferedInputStream(rawIn, 64 * 1024)
            val header = readWavHeaderFromStream(bis) ?: return@use false
            if (header.audioFormat != 1 && header.audioFormat != 3) return@use false // PCM or IEEE float

            val resampler = StreamingLinearResampler(header.sampleRate, TARGET_SAMPLE_RATE)
            val bytesPerSample = header.bitsPerSample / 8
            val frameBytes = bytesPerSample * header.channels
            if (frameBytes <= 0) return@use false

            val buf = ByteArray(frameBytes * 2048)
            var remainingData = header.dataSizeBytes
            while (remainingData > 0) {
                currentCoroutineContext().ensureActive()
                val toRead = min(buf.size.toLong(), remainingData).toInt()
                val read = bis.read(buf, 0, toRead)
                if (read <= 0) break
                val usable = (read / frameBytes) * frameBytes
                if (usable > 0) {
                    val mono = pcmBytesToMonoFloat(
                        bytes = buf,
                        length = usable,
                        channels = header.channels,
                        bitsPerSample = header.bitsPerSample,
                        isFloat = header.audioFormat == 3,
                    )
                    val resampled = resampler.resample(mono)
                    writer.appendSamples(resampled)
                }
                remainingData -= read
            }
            true
        }
    }

    private suspend fun decodeWithMediaCodec(
        context: Context,
        uri: Uri,
        writer: StreamingChunkWriter,
    ) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            val audioTrackIndex = findAudioTrack(extractor)
            require(audioTrackIndex >= 0) { "No audio track found in selected file." }
            extractor.selectTrack(audioTrackIndex)

            val format = extractor.getTrackFormat(audioTrackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)
                ?: error("Unsupported audio format: missing MIME type.")
            var inputSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channelCount = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var pcmEncodingBits = 16

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            var resampler = StreamingLinearResampler(inputSampleRate, TARGET_SAMPLE_RATE)
            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                currentCoroutineContext().ensureActive()
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val inBuffer = codec.getInputBuffer(inIdx)
                        if (inBuffer != null) {
                            val sampleSize = extractor.readSampleData(inBuffer, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(
                                    inIdx,
                                    0,
                                    0,
                                    0L,
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM,
                                )
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(
                                    inIdx,
                                    0,
                                    sampleSize,
                                    extractor.sampleTime,
                                    0,
                                )
                                extractor.advance()
                            }
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                when {
                    outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFmt = codec.outputFormat
                        if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                            inputSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        }
                        if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            channelCount = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                        if (outFmt.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            val enc = outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                            pcmEncodingBits = when (enc) {
                                android.media.AudioFormat.ENCODING_PCM_8BIT -> 8
                                android.media.AudioFormat.ENCODING_PCM_FLOAT -> 32
                                else -> 16
                            }
                        }
                        resampler = StreamingLinearResampler(inputSampleRate, TARGET_SAMPLE_RATE)
                    }
                    outIdx >= 0 -> {
                        val outBuffer = codec.getOutputBuffer(outIdx)
                        if (outBuffer != null && bufferInfo.size > 0) {
                            outBuffer.position(bufferInfo.offset)
                            outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                            val chunkBytes = ByteArray(bufferInfo.size)
                            outBuffer.get(chunkBytes)

                            val mono = pcmBytesToMonoFloat(
                                bytes = chunkBytes,
                                length = chunkBytes.size,
                                channels = channelCount,
                                bitsPerSample = pcmEncodingBits,
                                isFloat = pcmEncodingBits == 32,
                            )
                            val resampled = resampler.resample(mono)
                            writer.appendSamples(resampled)
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                }
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun findAudioTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) return i
        }
        return -1
    }

    private fun inferMimeType(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.endsWith(".wav") -> "audio/wav"
            lower.endsWith(".mp3") -> "audio/mpeg"
            lower.endsWith(".m4a") || lower.endsWith(".mp4") -> "audio/mp4"
            lower.endsWith(".ogg") || lower.endsWith(".opus") -> "audio/ogg"
            lower.endsWith(".flac") -> "audio/flac"
            else -> "audio/*"
        }
    }

    private data class WavHeaderInfo(
        val audioFormat: Int,
        val channels: Int,
        val sampleRate: Int,
        val bitsPerSample: Int,
        val dataSizeBytes: Long,
        val durationMs: Long,
    )

    private fun tryReadWavHeader(inputStream: InputStream?): WavHeaderInfo? {
        if (inputStream == null) return null
        return inputStream.use { readWavHeaderFromStream(BufferedInputStream(it, 4096)) }
    }

    private fun readWavHeaderFromStream(bis: BufferedInputStream): WavHeaderInfo? {
        val riff = ByteArray(12)
        if (readFully(bis, riff) < 12) return null
        if (String(riff, 0, 4) != "RIFF" || String(riff, 8, 4) != "WAVE") return null

        var audioFormat = 1
        var channels = 1
        var sampleRate = 16000
        var bitsPerSample = 16
        var foundFmt = false

        val chunkHeader = ByteArray(8)
        while (readFully(bis, chunkHeader) == 8) {
            val id = String(chunkHeader, 0, 4)
            val size = ByteBuffer.wrap(chunkHeader, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
            if (id == "fmt ") {
                val fmtBytes = ByteArray(size.toInt().coerceAtMost(256))
                if (readFully(bis, fmtBytes) < 16) return null
                val bb = ByteBuffer.wrap(fmtBytes).order(ByteOrder.LITTLE_ENDIAN)
                audioFormat = bb.short.toInt() and 0xFFFF
                channels = bb.short.toInt() and 0xFFFF
                sampleRate = bb.int
                bb.int // byteRate
                bb.short // blockAlign
                bitsPerSample = bb.short.toInt() and 0xFFFF
                val extra = size - fmtBytes.size
                if (extra > 0) skipFully(bis, extra)
                foundFmt = true
            } else if (id == "data" && foundFmt) {
                val bytesPerSec = sampleRate.toLong() * channels * (bitsPerSample / 8)
                val durationMs = if (bytesPerSec > 0) (size * 1000L) / bytesPerSec else 0L
                return WavHeaderInfo(
                    audioFormat = audioFormat,
                    channels = channels,
                    sampleRate = sampleRate,
                    bitsPerSample = bitsPerSample,
                    dataSizeBytes = size,
                    durationMs = durationMs,
                )
            } else {
                skipFully(bis, size + (size % 2))
            }
        }
        return null
    }

    private fun readFully(stream: InputStream, dest: ByteArray): Int {
        var offset = 0
        while (offset < dest.size) {
            val r = stream.read(dest, offset, dest.size - offset)
            if (r <= 0) break
            offset += r
        }
        return offset
    }

    private fun skipFully(stream: InputStream, bytes: Long) {
        var rem = bytes
        while (rem > 0) {
            val skipped = stream.skip(rem)
            if (skipped <= 0) {
                if (stream.read() == -1) break
                rem -= 1
            } else {
                rem -= skipped
            }
        }
    }

    private fun pcmBytesToMonoFloat(
        bytes: ByteArray,
        length: Int,
        channels: Int,
        bitsPerSample: Int,
        isFloat: Boolean,
    ): FloatArray {
        val bytesPerSample = bitsPerSample / 8
        val frameSize = bytesPerSample * channels.coerceAtLeast(1)
        val frames = length / frameSize
        val out = FloatArray(frames)
        val bb = ByteBuffer.wrap(bytes, 0, length).order(ByteOrder.LITTLE_ENDIAN)

        for (i in 0 until frames) {
            var sum = 0f
            for (c in 0 until channels) {
                val sample = when {
                    isFloat && bitsPerSample == 32 -> bb.float.coerceIn(-1f, 1f)
                    bitsPerSample == 16 -> bb.short / 32768f
                    bitsPerSample == 8 -> ((bb.get().toInt() and 0xFF) - 128) / 128f
                    bitsPerSample == 24 -> {
                        val b0 = bb.get().toInt() and 0xFF
                        val b1 = bb.get().toInt() and 0xFF
                        val b2 = bb.get().toInt()
                        val raw = (b2 shl 16) or (b1 shl 8) or b0
                        raw / 8388608f
                    }
                    else -> 0f
                }
                sum += sample
            }
            out[i] = (sum / channels.coerceAtLeast(1)).coerceIn(-1f, 1f)
        }
        return out
    }
}

class StreamingLinearResampler(
    private val inputRate: Int,
    private val outputRate: Int,
) {
    private var prevSample = 0f
    private var hasPrev = false
    private var fracPos = 0.0

    fun resample(input: FloatArray): ShortArray {
        if (input.isEmpty()) return ShortArray(0)
        if (inputRate == outputRate) {
            return ShortArray(input.size) { i ->
                (input[i].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
            }
        }

        val step = inputRate.toDouble() / outputRate.toDouble()
        val estimatedOut = ((input.size / step) + 4).toInt().coerceAtLeast(1)
        val out = ArrayList<Short>(estimatedOut)

        if (!hasPrev) {
            prevSample = input[0]
            hasPrev = true
        }

        var pos = fracPos
        while (pos < input.size.toDouble()) {
            val idx = pos.toInt()
            val frac = (pos - idx).toFloat()
            val s0 = if (idx == 0) prevSample else input[idx - 1]
            val s1 = input[idx.coerceIn(0, input.lastIndex)]
            val interp = s0 + (s1 - s0) * frac
            out.add((interp.coerceIn(-1f, 1f) * 32767f).roundToInt().toShort())
            pos += step
        }

        fracPos = pos - input.size.toDouble()
        prevSample = input.last()
        return out.toShortArray()
    }
}

private class StreamingChunkWriter(
    private val jobDir: File,
    private val chunkSamplesTarget: Int,
    private val overlapSamples: Int,
    private val vadSplitEnabled: Boolean,
    private val vadLookaheadSamples: Int,
    private val expectedTotalSamples: Long,
    private val onProgress: (Float, Int) -> Unit,
) {
    private val buffer = ShortArray(chunkSamplesTarget + vadLookaheadSamples + 32000)
    private var bufferedCount = 0
    private var nextChunkStartSample = 0L
    private var totalAppendedSamples = 0L
    private val chunks = mutableListOf<SplitChunkInfo>()
    private val globalPeaks = mutableListOf<Float>()

    fun appendSamples(samples: ShortArray) {
        var offset = 0
        while (offset < samples.size) {
            val space = buffer.size - bufferedCount
            val toCopy = min(space, samples.size - offset)
            System.arraycopy(samples, offset, buffer, bufferedCount, toCopy)
            bufferedCount += toCopy
            offset += toCopy
            totalAppendedSamples += toCopy

            val triggerThreshold = chunkSamplesTarget + (if (vadSplitEnabled) vadLookaheadSamples else 0)
            while (bufferedCount >= triggerThreshold) {
                flushOneChunk(isFinal = false)
            }
        }
    }

    fun finish(): SplitResult {
        while (bufferedCount > 2400 || (chunks.isEmpty() && bufferedCount > 0)) {
            flushOneChunk(isFinal = bufferedCount <= chunkSamplesTarget)
            if (bufferedCount <= 2400 && chunks.isNotEmpty()) break
        }

        val durationMs = (totalAppendedSamples * 1000L) / AudioSplitter.TARGET_SAMPLE_RATE
        val downsampledGlobal = downsamplePeaks(globalPeaks, 72)
        onProgress(1f, chunks.size)
        return SplitResult(
            durationMs = durationMs,
            chunks = chunks,
            globalPeaksCsv = downsampledGlobal.joinToString(",") { "%.3f".format(it) },
        )
    }

    private fun flushOneChunk(isFinal: Boolean) {
        val splitLen = if (isFinal || bufferedCount <= chunkSamplesTarget) {
            bufferedCount
        } else if (vadSplitEnabled) {
            findLowestEnergySplitPoint(
                samples = buffer,
                minIdx = (chunkSamplesTarget - vadLookaheadSamples).coerceAtLeast(chunkSamplesTarget / 2),
                maxIdx = chunkSamplesTarget.coerceAtMost(bufferedCount),
            )
        } else {
            chunkSamplesTarget
        }

        val chunkIndex = chunks.size
        val startMs = (nextChunkStartSample * 1000L) / AudioSplitter.TARGET_SAMPLE_RATE
        val endMs = ((nextChunkStartSample + splitLen) * 1000L) / AudioSplitter.TARGET_SAMPLE_RATE
        val chunkFile = File(jobDir, "chunk_%04d.pcm".format(chunkIndex))

        writePcm16Le(chunkFile, buffer, splitLen)
        val chunkPeaks = computePeaks(buffer, splitLen, 32)
        globalPeaks.addAll(chunkPeaks)

        chunks.add(
            SplitChunkInfo(
                chunkIndex = chunkIndex,
                startMs = startMs,
                endMs = endMs,
                pcmFilePath = chunkFile.absolutePath,
                sampleCount = splitLen,
                peaksCsv = chunkPeaks.joinToString(",") { "%.3f".format(it) },
            )
        )

        val progress = (totalAppendedSamples.toFloat() / expectedTotalSamples.toFloat()).coerceIn(0f, 0.98f)
        onProgress(progress, chunks.size)

        if (isFinal && splitLen == bufferedCount) {
            bufferedCount = 0
            return
        }

        val effectiveOverlap = overlapSamples.coerceAtMost(splitLen / 2)
        val advance = (splitLen - effectiveOverlap).coerceAtLeast(1)
        val remaining = bufferedCount - advance
        if (remaining > 0) {
            System.arraycopy(buffer, advance, buffer, 0, remaining)
        }
        bufferedCount = remaining.coerceAtLeast(0)
        nextChunkStartSample += advance
    }

    private fun findLowestEnergySplitPoint(samples: ShortArray, minIdx: Int, maxIdx: Int): Int {
        val windowSize = 800 // 50ms at 16kHz
        if (maxIdx - minIdx <= windowSize) return maxIdx
        var bestPos = maxIdx
        var minEnergy = Double.MAX_VALUE
        var pos = minIdx
        while (pos + windowSize <= maxIdx) {
            var sumSq = 0.0
            for (i in pos until pos + windowSize) {
                val s = samples[i] / 32768.0
                sumSq += s * s
            }
            val rms = sqrt(sumSq / windowSize)
            if (rms < minEnergy) {
                minEnergy = rms
                bestPos = pos + (windowSize / 2)
            }
            pos += windowSize / 2
        }
        return bestPos
    }

    private fun writePcm16Le(file: File, samples: ShortArray, count: Int) {
        DataOutputStream(BufferedOutputStream(FileOutputStream(file), 32 * 1024)).use { out ->
            val byteBuf = ByteArray(count * 2)
            for (i in 0 until count) {
                val s = samples[i].toInt()
                byteBuf[i * 2] = (s and 0xFF).toByte()
                byteBuf[i * 2 + 1] = ((s ushr 8) and 0xFF).toByte()
            }
            out.write(byteBuf)
        }
    }

    private fun computePeaks(samples: ShortArray, count: Int, bins: Int): List<Float> {
        if (count <= 0) return List(bins) { 0.05f }
        val step = (count / bins).coerceAtLeast(1)
        return List(bins) { b ->
            val start = b * step
            val end = min(count, start + step)
            var sumSq = 0.0
            for (i in start until end) {
                val v = samples[i] / 32768.0
                sumSq += v * v
            }
            val rms = if (end > start) sqrt(sumSq / (end - start)).toFloat() else 0f
            (rms * 3.2f).coerceIn(0.04f, 1.0f)
        }
    }

    private fun downsamplePeaks(peaks: List<Float>, targetCount: Int): List<Float> {
        if (peaks.isEmpty()) return List(targetCount) { 0.08f }
        if (peaks.size <= targetCount) return peaks
        val step = peaks.size.toFloat() / targetCount
        return List(targetCount) { i ->
            val idx = (i * step).toInt().coerceIn(0, peaks.lastIndex)
            peaks[idx]
        }
    }
}
