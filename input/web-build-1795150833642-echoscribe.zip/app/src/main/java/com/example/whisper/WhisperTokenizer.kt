package com.example.whisper

import android.util.Base64
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Decodes Whisper token IDs using user-imported vocabulary files:
 * - filters_vocab_*.bin (whisper.cpp / whisper_android binary format)
 * - tokens.txt (sherpa-onnx / Whisper line format)
 * - vocab.json (HuggingFace GPT-2 BPE token map)
 */
class WhisperTokenizer(
    private val idToToken: Map<Int, String> = emptyMap(),
    val vocabSize: Int = idToToken.size,
) {
    private val byteDecoder: Map<Char, Int> by lazy { buildGpt2ByteDecoder() }

    fun decodeTokens(tokenIds: IntArray): String {
        if (tokenIds.isEmpty()) return ""
        val rawPieces = mutableListOf<String>()
        val byteAccumulator = mutableListOf<Byte>()

        fun flushBytes() {
            if (byteAccumulator.isNotEmpty()) {
                rawPieces.add(String(byteAccumulator.toByteArray(), Charsets.UTF_8))
                byteAccumulator.clear()
            }
        }

        for (id in tokenIds) {
            if (id == TOKEN_EOT) break
            if (isSpecialToken(id)) continue

            val token = idToToken[id]
            if (token != null) {
                if (token.startsWith("<|") && token.endsWith("|>")) continue
                // Decode GPT-2 BPE unicode characters back to UTF-8 bytes when using vocab.json
                var allGpt2Bytes = true
                val decodedBytes = ByteArray(token.length)
                for (i in token.indices) {
                    val b = byteDecoder[token[i]]
                    if (b == null) {
                        allGpt2Bytes = false
                        break
                    }
                    decodedBytes[i] = b.toByte()
                }
                if (allGpt2Bytes && idToToken.size > 40000 && token.any { it.code >= 0x100 || it == 'Ġ' || it == 'Ċ' }) {
                    byteAccumulator.addAll(decodedBytes.toList())
                } else {
                    flushBytes()
                    rawPieces.add(token)
                }
            } else if (id in 0..255) {
                // Fallback for direct byte tokens if no full vocab is attached
                byteAccumulator.add(id.toByte())
            }
        }
        flushBytes()

        return rawPieces.joinToString("")
            .replace("\\s+".toRegex(), " ")
            .trim()
    }

    companion object {
        const val TOKEN_EOT = 50257
        const val TOKEN_SOT = 50258
        const val TOKEN_TRANSLATE = 50358
        const val TOKEN_TRANSCRIBE = 50359
        const val TOKEN_SOLM = 50361
        const val TOKEN_PREV = 50362
        const val TOKEN_NO_SPEECH = 50363
        const val TOKEN_NO_TIMESTAMPS = 50364
        const val TOKEN_TIMESTAMP_BEGIN = 50365

        private val LANGUAGE_IDS = mapOf(
            "en" to 50259,
            "zh" to 50260,
            "de" to 50261,
            "es" to 50262,
            "ru" to 50263,
            "ko" to 50264,
            "fr" to 50265,
            "ja" to 50266,
            "pt" to 50267,
            "tr" to 50268,
            "pl" to 50269,
            "ca" to 50270,
            "nl" to 50271,
            "ar" to 50272,
            "sv" to 50273,
            "it" to 50274,
            "id" to 50275,
            "hi" to 50276,
            "fi" to 50277,
            "vi" to 50278,
            "he" to 50279,
            "uk" to 50280,
            "el" to 50281,
            "ms" to 50282,
            "cs" to 50283,
            "ro" to 50284,
            "da" to 50285,
            "hu" to 50286,
            "ta" to 50287,
            "bn" to 50302,
        )

        fun languageTokenId(code: String): Int? = LANGUAGE_IDS[code.lowercase()]

        fun isSpecialToken(id: Int): Boolean {
            return id >= TOKEN_EOT
        }

        fun loadFromFile(vocabPath: String?): WhisperTokenizer {
            if (vocabPath.isNullOrBlank()) return WhisperTokenizer()
            val file = File(vocabPath)
            if (!file.exists()) return WhisperTokenizer()

            return when {
                vocabPath.endsWith(".json", ignoreCase = true) -> loadFromVocabJson(file)
                vocabPath.endsWith(".txt", ignoreCase = true) -> loadFromTokensTxt(file)
                else -> loadFromFiltersVocabBin(file)
            }
        }

        private fun loadFromVocabJson(file: File): WhisperTokenizer {
            val map = HashMap<Int, String>(52000)
            val text = file.readText(Charsets.UTF_8)
            val json = JSONObject(text)
            val keys = json.keys()
            while (keys.hasNext()) {
                val token = keys.next()
                val id = json.optInt(token, -1)
                if (id >= 0) map[id] = token
            }
            return WhisperTokenizer(map, map.size)
        }

        private fun loadFromTokensTxt(file: File): WhisperTokenizer {
            val map = HashMap<Int, String>(52000)
            file.forEachLine(Charsets.UTF_8) { line ->
                val trimmed = line.trimEnd()
                if (trimmed.isEmpty()) return@forEachLine
                val lastSpace = trimmed.lastIndexOf(' ')
                if (lastSpace > 0) {
                    val left = trimmed.substring(0, lastSpace)
                    val right = trimmed.substring(lastSpace + 1).toIntOrNull()
                    if (right != null) {
                        val decoded = runCatching {
                            String(Base64.decode(left, Base64.DEFAULT), Charsets.UTF_8)
                        }.getOrNull()
                        // Use decoded base64 if it looks cleanly encoded in sherpa-onnx format, else raw token
                        val piece = if (decoded != null && !left.contains(' ') && left.matches(Regex("^[A-Za-z0-9+/=]+$")) && left.length >= 4) {
                            decoded
                        } else {
                            left
                        }
                        map[right] = piece
                    }
                }
            }
            return WhisperTokenizer(map, map.size)
        }

        private fun loadFromFiltersVocabBin(file: File): WhisperTokenizer {
            val map = HashMap<Int, String>(52000)
            BufferedInputStream(FileInputStream(file), 64 * 1024).use { bis ->
                val bytes = bis.readBytes()
                if (bytes.size < 16) return WhisperTokenizer()
                val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                val magic = bb.int
                // vilassn/whisper_android filters_vocab_*.bin format:
                // magic (0x55534552 or 0x54464c54), nMel (80), nFft (201), float[80*201], nVocab, [int len, bytes]...
                if (magic == 0x55534552 || magic == 0x54464C54 || magic == 0x57485350) {
                    val nMel = bb.int
                    val nFft = bb.int
                    val filterBytes = nMel * nFft * 4
                    if (bb.remaining() >= filterBytes + 4) {
                        bb.position(bb.position() + filterBytes)
                    }
                } else {
                    bb.position(0)
                }

                if (bb.remaining() >= 4) {
                    val nVocab = bb.int
                    if (nVocab in 1000..100000) {
                        for (id in 0 until nVocab) {
                            if (bb.remaining() < 4) break
                            val len = bb.int
                            if (len < 0 || len > 512 || bb.remaining() < len) break
                            val strBytes = ByteArray(len)
                            bb.get(strBytes)
                            map[id] = String(strBytes, Charsets.UTF_8)
                        }
                    }
                }
            }
            return WhisperTokenizer(map, map.size)
        }

        private fun buildGpt2ByteDecoder(): Map<Char, Int> {
            val bs = mutableListOf<Int>()
            for (b in 33..126) bs.add(b)
            for (b in 161..172) bs.add(b)
            for (b in 174..255) bs.add(b)
            val cs = bs.toMutableList()
            var n = 0
            for (b in 0..255) {
                if (!bs.contains(b)) {
                    bs.add(b)
                    cs.add(256 + n)
                    n++
                }
            }
            val decoder = HashMap<Char, Int>(256)
            for (i in bs.indices) {
                decoder[cs[i].toChar()] = bs[i]
            }
            return decoder
        }
    }
}
