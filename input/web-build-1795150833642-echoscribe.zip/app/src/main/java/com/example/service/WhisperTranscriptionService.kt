package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.net.toUri
import com.example.MainActivity
import com.example.R
import com.example.audio.AudioSplitter
import com.example.audio.WhisperAudioProcessor
import com.example.data.db.AudioChunkEntity
import com.example.data.db.ChunkStatus
import com.example.data.db.EchoScribeDatabase
import com.example.data.db.JobStatus
import com.example.data.db.ModelFormat
import com.example.data.db.TranscriptionJobEntity
import com.example.data.repo.ModelRepository
import com.example.data.repo.TranscriptionRepository
import com.example.whisper.TranscriptStitcher
import com.example.whisper.WhisperEngine
import com.example.whisper.WhisperEngineFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class LivePipelineTelemetry(
    val activeJobId: String? = null,
    val phaseLabel: String = "",
    val splitProgress: Float = 0f,
    val currentChunkIndex: Int = 0,
    val totalChunks: Int = 0,
    val lastChunkInferenceMs: Long = 0L,
    val averageChunkMs: Long = 0L,
    val estimatedRemainingMs: Long = 0L,
    val realTimeFactor: Float = 0f,
)

object PipelineTelemetryBus {
    private val _telemetry = MutableStateFlow(LivePipelineTelemetry())
    val telemetry: StateFlow<LivePipelineTelemetry> = _telemetry.asStateFlow()

    fun update(value: LivePipelineTelemetry) {
        _telemetry.value = value
    }

    fun clear() {
        _telemetry.value = LivePipelineTelemetry()
    }
}

class WhisperTranscriptionService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var currentTask: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile
    private var pauseRequested = false
    @Volatile
    private var cancelRequested = false

    private lateinit var transcriptionRepo: TranscriptionRepository
    private lateinit var modelRepo: ModelRepository

    override fun onCreate() {
        super.onCreate()
        val dao = EchoScribeDatabase.getInstance(applicationContext).echoScribeDao()
        transcriptionRepo = TranscriptionRepository(applicationContext, dao)
        modelRepo = ModelRepository(applicationContext, dao)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_NEW -> {
                val uriString = intent.getStringExtra(EXTRA_URI) ?: return START_NOT_STICKY
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Audio Transcription"
                val fileName = intent.getStringExtra(EXTRA_FILENAME) ?: "audio"
                val durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 0L)
                val sampleRate = intent.getIntExtra(EXTRA_SAMPLE_RATE, 16000)
                val modelId = intent.getStringExtra(EXTRA_MODEL_ID) ?: return START_NOT_STICKY
                val chunkSec = intent.getIntExtra(EXTRA_CHUNK_SEC, 30)
                val overlapSec = intent.getIntExtra(EXTRA_OVERLAP_SEC, 2)
                val vadSplit = intent.getBooleanExtra(EXTRA_VAD_SPLIT, true)
                val cpuThreads = intent.getIntExtra(EXTRA_CPU_THREADS, 4)
                val language = intent.getStringExtra(EXTRA_LANGUAGE) ?: "en"
                val translate = intent.getBooleanExtra(EXTRA_TRANSLATE, false)

                pauseRequested = false
                cancelRequested = false
                startForegroundCompat(buildNotification("Preparing audio...", 0, 100, indeterminate = true))
                launchNewJob(
                    uriString = uriString,
                    title = title,
                    fileName = fileName,
                    durationMs = durationMs,
                    sampleRate = sampleRate,
                    modelId = modelId,
                    chunkSec = chunkSec,
                    overlapSec = overlapSec,
                    vadSplit = vadSplit,
                    cpuThreads = cpuThreads,
                    language = language,
                    translate = translate,
                )
            }

            ACTION_RESUME_JOB -> {
                val jobId = intent.getStringExtra(EXTRA_JOB_ID) ?: return START_NOT_STICKY
                val singleChunkId = intent.getStringExtra(EXTRA_CHUNK_ID)
                pauseRequested = false
                cancelRequested = false
                startForegroundCompat(buildNotification("Resuming CPU transcription...", 0, 100, indeterminate = true))
                resumeExistingJob(jobId, singleChunkId)
            }

            ACTION_PAUSE -> {
                pauseRequested = true
            }

            ACTION_CANCEL -> {
                cancelRequested = true
                currentTask?.cancel()
            }
        }
        return START_NOT_STICKY
    }

    private fun launchNewJob(
        uriString: String,
        title: String,
        fileName: String,
        durationMs: Long,
        sampleRate: Int,
        modelId: String,
        chunkSec: Int,
        overlapSec: Int,
        vadSplit: Boolean,
        cpuThreads: Int,
        language: String,
        translate: Boolean,
    ) {
        currentTask?.cancel()
        currentTask = serviceScope.launch {
            acquireWakeLock()
            val jobId = UUID.randomUUID().toString()
            var engine: WhisperEngine? = null
            try {
                val model = EchoScribeDatabase.getInstance(applicationContext)
                    .echoScribeDao()
                    .getModelById(modelId)
                    ?: error("Selected Whisper model not found.")

                val initialJob = TranscriptionJobEntity(
                    id = jobId,
                    title = title,
                    sourceFileName = fileName,
                    sourceUriString = uriString,
                    totalDurationMs = durationMs,
                    sampleRateHz = sampleRate,
                    chunkDurationSec = chunkSec,
                    overlapSec = overlapSec,
                    totalChunks = 0,
                    completedChunks = 0,
                    status = JobStatus.SPLITTING.name,
                    modelId = model.id,
                    modelName = model.name,
                    languageCode = language,
                    translateToEnglish = translate,
                    cpuThreads = cpuThreads,
                )
                transcriptionRepo.upsertJob(initialJob)
                PipelineTelemetryBus.update(
                    LivePipelineTelemetry(
                        activeJobId = jobId,
                        phaseLabel = "Decoding & splitting audio into ${chunkSec}s pieces...",
                        splitProgress = 0.02f,
                    )
                )

                val splitResult = AudioSplitter.splitAudioToChunks(
                    context = applicationContext,
                    uri = uriString.toUri(),
                    jobId = jobId,
                    chunkDurationSec = chunkSec,
                    overlapSec = overlapSec,
                    vadSplitEnabled = vadSplit,
                    expectedDurationMs = durationMs,
                    onProgress = { progress, chunksReady ->
                        PipelineTelemetryBus.update(
                            LivePipelineTelemetry(
                                activeJobId = jobId,
                                phaseLabel = "Splitting audio ($chunksReady pieces ready)...",
                                splitProgress = progress,
                                totalChunks = chunksReady,
                            )
                        )
                        updateNotification(
                            buildNotification(
                                "Splitting long audio ($chunksReady chunks)...",
                                (progress * 100).toInt(),
                                100,
                                indeterminate = false,
                            )
                        )
                    },
                )

                val chunkEntities = splitResult.chunks.map { info ->
                    AudioChunkEntity(
                        id = "${jobId}_chunk_${info.chunkIndex}",
                        jobId = jobId,
                        chunkIndex = info.chunkIndex,
                        startMs = info.startMs,
                        endMs = info.endMs,
                        pcmFilePath = info.pcmFilePath,
                        status = ChunkStatus.PENDING.name,
                        peaksCsv = info.peaksCsv,
                    )
                }
                transcriptionRepo.upsertChunks(chunkEntities)

                val readyJob = initialJob.copy(
                    totalDurationMs = splitResult.durationMs.coerceAtLeast(durationMs),
                    totalChunks = chunkEntities.size,
                    waveformPeaksCsv = splitResult.globalPeaksCsv,
                    status = JobStatus.TRANSCRIBING.name,
                    updatedAt = System.currentTimeMillis(),
                )
                transcriptionRepo.upsertJob(readyJob)

                engine = WhisperEngineFactory.create(ModelFormat.valueOf(model.format))
                PipelineTelemetryBus.update(
                    LivePipelineTelemetry(
                        activeJobId = jobId,
                        phaseLabel = "Loading ${model.name} on $cpuThreads CPU threads...",
                        splitProgress = 1f,
                        totalChunks = chunkEntities.size,
                    )
                )
                engine.load(model, cpuThreads)

                processChunks(readyJob, chunkEntities, engine)
            } catch (_: CancellationException) {
                markJobStatus(jobId, JobStatus.CANCELLED, null)
            } catch (e: Exception) {
                markJobStatus(jobId, JobStatus.FAILED, e.message ?: "Transcription failed.")
            } finally {
                runCatching { engine?.release() }
                PipelineTelemetryBus.clear()
                releaseWakeLock()
                stopSelfGracefully()
            }
        }
    }

    private fun resumeExistingJob(jobId: String, singleChunkId: String?) {
        currentTask?.cancel()
        currentTask = serviceScope.launch {
            acquireWakeLock()
            var engine: WhisperEngine? = null
            try {
                val job = transcriptionRepo.getJob(jobId) ?: error("Transcription job not found.")
                val model = EchoScribeDatabase.getInstance(applicationContext)
                    .echoScribeDao()
                    .getModelById(job.modelId)
                    ?: modelRepo.getSelectedModel()
                    ?: error("No Whisper model available to resume.")

                val updatedJob = job.copy(
                    status = JobStatus.TRANSCRIBING.name,
                    errorMessage = null,
                    modelId = model.id,
                    modelName = model.name,
                    updatedAt = System.currentTimeMillis(),
                )
                transcriptionRepo.upsertJob(updatedJob)

                val allChunks = transcriptionRepo.getChunks(jobId)
                val targetChunks = if (singleChunkId != null) {
                    allChunks.filter { it.id == singleChunkId }
                } else {
                    allChunks.filter { it.status != ChunkStatus.COMPLETED.name }
                }

                engine = WhisperEngineFactory.create(ModelFormat.valueOf(model.format))
                PipelineTelemetryBus.update(
                    LivePipelineTelemetry(
                        activeJobId = jobId,
                        phaseLabel = "Loading ${model.name} on ${updatedJob.cpuThreads} CPU threads...",
                        splitProgress = 1f,
                        totalChunks = allChunks.size,
                    )
                )
                engine.load(model, updatedJob.cpuThreads)

                processChunks(updatedJob, targetChunks, engine)
            } catch (_: CancellationException) {
                markJobStatus(jobId, JobStatus.CANCELLED, null)
            } catch (e: Exception) {
                markJobStatus(jobId, JobStatus.FAILED, e.message ?: "Resume failed.")
            } finally {
                runCatching { engine?.release() }
                PipelineTelemetryBus.clear()
                releaseWakeLock()
                stopSelfGracefully()
            }
        }
    }

    private suspend fun processChunks(
        job: TranscriptionJobEntity,
        chunksToProcess: List<AudioChunkEntity>,
        engine: WhisperEngine,
    ) {
        val allChunks = transcriptionRepo.getChunks(job.id).toMutableList()
        val totalCount = allChunks.size.coerceAtLeast(1)
        var cumulativeInferenceMs = 0L
        var processedInSession = 0

        for (target in chunksToProcess) {
            if (cancelRequested) throw CancellationException()
            if (pauseRequested) {
                markJobStatus(job.id, JobStatus.PAUSED, null)
                return
            }

            val processingChunk = target.copy(status = ChunkStatus.PROCESSING.name, errorMessage = null)
            transcriptionRepo.upsertChunk(processingChunk)

            PipelineTelemetryBus.update(
                LivePipelineTelemetry(
                    activeJobId = job.id,
                    phaseLabel = "Transcribing chunk ${target.chunkIndex + 1} of $totalCount on CPU...",
                    splitProgress = 1f,
                    currentChunkIndex = target.chunkIndex,
                    totalChunks = totalCount,
                    averageChunkMs = if (processedInSession > 0) cumulativeInferenceMs / processedInSession else 0L,
                )
            )
            updateNotification(
                buildNotification(
                    "Chunk ${target.chunkIndex + 1} / $totalCount • ${job.modelName}",
                    target.chunkIndex,
                    totalCount,
                    indeterminate = false,
                )
            )

            val pcm16 = WhisperAudioProcessor.readPcm16File(target.pcmFilePath)
            val result = engine.transcribeChunk(
                pcm16 = pcm16,
                languageCode = job.languageCode,
                translateToEnglish = job.translateToEnglish,
            )

            val doneChunk = processingChunk.copy(
                status = ChunkStatus.COMPLETED.name,
                rawText = result.text,
                inferenceMs = result.inferenceMs,
            )
            transcriptionRepo.upsertChunk(doneChunk)

            val listIdx = allChunks.indexOfFirst { it.id == doneChunk.id }
            if (listIdx >= 0) allChunks[listIdx] = doneChunk

            processedInSession++
            cumulativeInferenceMs += result.inferenceMs
            val avgChunkMs = cumulativeInferenceMs / processedInSession
            val remainingChunks = allChunks.count { it.status != ChunkStatus.COMPLETED.name }
            val chunkAudioDurationMs = (target.endMs - target.startMs).coerceAtLeast(1000L)
            val rtf = result.inferenceMs.toFloat() / chunkAudioDurationMs.toFloat()

            val stitched = TranscriptStitcher.stitchChunks(allChunks)
            val completedCount = allChunks.count { it.status == ChunkStatus.COMPLETED.name }

            val latestJob = transcriptionRepo.getJob(job.id) ?: job
            transcriptionRepo.upsertJob(
                latestJob.copy(
                    completedChunks = completedCount,
                    stitchedTranscript = stitched,
                    processingTimeMs = latestJob.processingTimeMs + result.inferenceMs,
                    updatedAt = System.currentTimeMillis(),
                )
            )

            PipelineTelemetryBus.update(
                LivePipelineTelemetry(
                    activeJobId = job.id,
                    phaseLabel = "Connected $completedCount / $totalCount pieces",
                    splitProgress = 1f,
                    currentChunkIndex = target.chunkIndex + 1,
                    totalChunks = totalCount,
                    lastChunkInferenceMs = result.inferenceMs,
                    averageChunkMs = avgChunkMs,
                    estimatedRemainingMs = remainingChunks * avgChunkMs,
                    realTimeFactor = rtf,
                )
            )
        }

        val finalChunks = transcriptionRepo.getChunks(job.id)
        val allCompleted = finalChunks.all { it.status == ChunkStatus.COMPLETED.name }
        val latestJob = transcriptionRepo.getJob(job.id) ?: job
        transcriptionRepo.upsertJob(
            latestJob.copy(
                completedChunks = finalChunks.count { it.status == ChunkStatus.COMPLETED.name },
                stitchedTranscript = TranscriptStitcher.stitchChunks(finalChunks),
                status = if (allCompleted) JobStatus.COMPLETED.name else JobStatus.PAUSED.name,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    private suspend fun markJobStatus(jobId: String, status: JobStatus, error: String?) {
        val job = transcriptionRepo.getJob(jobId) ?: return
        transcriptionRepo.upsertJob(
            job.copy(
                status = status.name,
                errorMessage = error,
                updatedAt = System.currentTimeMillis(),
            )
        )
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopSelfGracefully() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = getString(R.string.notification_channel_desc)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(notification: Notification) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(
        contentText: String,
        progress: Int,
        max: Int,
        indeterminate: Boolean,
    ): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val cancelIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, WhisperTranscriptionService::class.java).apply { action = ACTION_CANCEL },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("EchoScribe • Local Whisper CPU")
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent)
            .setProgress(max, progress, indeterminate)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelIntent)
            .build()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EchoScribe::CpuTranscription")
            .apply { acquire(3 * 60 * 60 * 1000L) }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        wakeLock = null
    }

    override fun onDestroy() {
        serviceScope.cancel()
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "echoscribe_transcription"
        private const val NOTIFICATION_ID = 4041

        const val ACTION_START_NEW = "com.example.action.START_NEW"
        const val ACTION_RESUME_JOB = "com.example.action.RESUME_JOB"
        const val ACTION_PAUSE = "com.example.action.PAUSE"
        const val ACTION_CANCEL = "com.example.action.CANCEL"

        const val EXTRA_URI = "extra_uri"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_FILENAME = "extra_filename"
        const val EXTRA_DURATION_MS = "extra_duration_ms"
        const val EXTRA_SAMPLE_RATE = "extra_sample_rate"
        const val EXTRA_MODEL_ID = "extra_model_id"
        const val EXTRA_CHUNK_SEC = "extra_chunk_sec"
        const val EXTRA_OVERLAP_SEC = "extra_overlap_sec"
        const val EXTRA_VAD_SPLIT = "extra_vad_split"
        const val EXTRA_CPU_THREADS = "extra_cpu_threads"
        const val EXTRA_LANGUAGE = "extra_language"
        const val EXTRA_TRANSLATE = "extra_translate"
        const val EXTRA_JOB_ID = "extra_job_id"
        const val EXTRA_CHUNK_ID = "extra_chunk_id"
    }
}
