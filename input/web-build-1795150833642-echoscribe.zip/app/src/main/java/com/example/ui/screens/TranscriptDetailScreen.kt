package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.IosShare
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.AudioChunkEntity
import com.example.data.db.ChunkStatus
import com.example.data.db.JobStatus
import com.example.data.db.TranscriptionJobEntity
import com.example.ui.components.StudioFormatters
import com.example.ui.components.TelemetryBadge
import com.example.ui.components.WaveformTimelineCanvas
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranscriptDetailScreen(
    job: TranscriptionJobEntity?,
    chunks: List<AudioChunkEntity>,
    onBack: () -> Unit,
    onResumeJob: (String) -> Unit,
    onRetryChunk: (String, String) -> Unit,
    onUpdateChunkText: (String, String) -> Unit,
    onBuildExport: suspend (String, String) -> String,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) } // 0 = Connected, 1 = Split Pieces
    var showExportMenu by remember { mutableStateOf(false) }
    var editingChunk by remember { mutableStateOf<AudioChunkEntity?>(null) }
    var fontScale by remember { mutableStateOf(16f) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = job?.title ?: "Transcript",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (job != null && job.stitchedTranscript.isNotBlank()) {
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(job.stitchedTranscript))
                                onShowMessage("Copied full transcript to clipboard.")
                            },
                            modifier = Modifier.testTag("copy_transcript_button"),
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy transcript")
                        }

                        Box {
                            IconButton(
                                onClick = { showExportMenu = true },
                                modifier = Modifier.testTag("export_transcript_button"),
                            ) {
                                Icon(Icons.Rounded.IosShare, contentDescription = "Export transcript")
                            }
                            DropdownMenu(
                                expanded = showExportMenu,
                                onDismissRequest = { showExportMenu = false },
                            ) {
                                listOf(
                                    "txt" to "Plain Text (.txt)",
                                    "srt" to "SubRip Subtitles (.srt)",
                                    "vtt" to "WebVTT Subtitles (.vtt)",
                                    "json" to "Structured Chunks (.json)",
                                ).forEach { (fmt, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        onClick = {
                                            showExportMenu = false
                                            scope.launch {
                                                val content = onBuildExport(job.id, fmt)
                                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_SUBJECT, "${job.title}.$fmt")
                                                    putExtra(Intent.EXTRA_TEXT, content)
                                                }
                                                context.startActivity(Intent.createChooser(shareIntent, "Export $label"))
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        if (job == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center,
            ) {
                Text("Transcript not found.")
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                // Telemetry strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    TelemetryBadge(text = StudioFormatters.formatCompactDuration(job.totalDurationMs))
                    TelemetryBadge(text = "${job.completedChunks}/${job.totalChunks} pieces")
                    TelemetryBadge(text = "${job.cpuThreads}T CPU")
                    if (job.processingTimeMs > 0L) {
                        TelemetryBadge(text = "CPU ${StudioFormatters.formatCompactDuration(job.processingTimeMs)}")
                    }
                }

                // Segmented view toggle
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                        modifier = Modifier.testTag("tab_connected_transcript"),
                    ) {
                        Text("Connected Transcript")
                    }
                    SegmentedButton(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                        modifier = Modifier.testTag("tab_split_pieces"),
                    ) {
                        Text("Split Pieces (${chunks.size})")
                    }
                }

                if (job.status == JobStatus.PAUSED.name || job.status == JobStatus.FAILED.name || job.status == JobStatus.CANCELLED.name) {
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Transcription ${job.status.lowercase()}",
                                    style = MaterialTheme.typography.titleSmall,
                                )
                                if (!job.errorMessage.isNullOrBlank()) {
                                    Text(
                                        text = job.errorMessage,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                            Button(onClick = { onResumeJob(job.id) }) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Resume")
                            }
                        }
                    }
                }

                if (selectedTab == 0) {
                    ConnectedTranscriptView(
                        job = job,
                        fontSizeSp = fontScale,
                        onAdjustFont = { delta -> fontScale = (fontScale + delta).coerceIn(13f, 22f) },
                    )
                } else {
                    SplitChunksListView(
                        chunks = chunks,
                        onEditChunk = { editingChunk = it },
                        onRetryChunk = { chunkId -> onRetryChunk(job.id, chunkId) },
                    )
                }
            }
        }
    }

    editingChunk?.let { chunk ->
        var textDraft by remember(chunk.id) { mutableStateOf(chunk.rawText) }
        AlertDialog(
            onDismissRequest = { editingChunk = null },
            title = { Text("Edit Piece #${chunk.chunkIndex + 1}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "${StudioFormatters.formatDurationMs(chunk.startMs)} – ${StudioFormatters.formatDurationMs(chunk.endMs)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedTextField(
                        value = textDraft,
                        onValueChange = { textDraft = it },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateChunkText(chunk.id, textDraft)
                        editingChunk = null
                    }
                ) {
                    Text("Save & Re-Stitch")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingChunk = null }) {
                    Text("Cancel")
                }
            },
        )
    }
}

@Composable
private fun ConnectedTranscriptView(
    job: TranscriptionJobEntity,
    fontSizeSp: Float,
    onAdjustFont: (Float) -> Unit,
) {
    val scroll = rememberScrollState()
    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "STITCHED OUTPUT (${job.overlapSec}s OVERLAP DEDUPED)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                )
                Row {
                    TextButton(onClick = { onAdjustFont(-1.5f) }) { Text("A-") }
                    TextButton(onClick = { onAdjustFont(1.5f) }) { Text("A+") }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scroll)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                if (job.stitchedTranscript.isBlank()) {
                    Text(
                        text = "No transcript text generated yet for this job. Check Split Pieces or ensure the selected model has a matching vocabulary file attached.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    SelectionContainer {
                        Text(
                            text = job.stitchedTranscript,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = fontSizeSp.sp,
                                lineHeight = (fontSizeSp * 1.55f).sp,
                            ),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SplitChunksListView(
    chunks: List<AudioChunkEntity>,
    onEditChunk: (AudioChunkEntity) -> Unit,
    onRetryChunk: (String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(chunks, key = { it.id }) { chunk ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TelemetryBadge(
                                text = "#${chunk.chunkIndex + 1}",
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            Text(
                                text = "${StudioFormatters.formatDurationMs(chunk.startMs)} – ${StudioFormatters.formatDurationMs(chunk.endMs)}",
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (chunk.inferenceMs > 0L) {
                                TelemetryBadge(text = "${chunk.inferenceMs}ms")
                            }
                            TelemetryBadge(
                                text = chunk.status,
                                containerColor = if (chunk.status == ChunkStatus.COMPLETED.name) {
                                    MaterialTheme.colorScheme.secondaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                            )
                        }
                    }

                    WaveformTimelineCanvas(
                        peaks = StudioFormatters.parsePeaks(chunk.peaksCsv),
                        progressFraction = if (chunk.status == ChunkStatus.COMPLETED.name) 1f else 0f,
                        modifier = Modifier.height(24.dp),
                    )

                    Text(
                        text = chunk.rawText.ifBlank { "(No speech decoded in this piece)" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (chunk.rawText.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.onSurface,
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        OutlinedButton(
                            onClick = { onEditChunk(chunk) },
                            modifier = Modifier.height(38.dp),
                        ) {
                            Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = { onRetryChunk(chunk.id) },
                            modifier = Modifier.height(38.dp),
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Re-run")
                        }
                    }
                }
            }
        }
    }
}
