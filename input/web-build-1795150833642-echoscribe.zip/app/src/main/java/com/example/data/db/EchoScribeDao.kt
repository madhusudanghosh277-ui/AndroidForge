package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EchoScribeDao {
    // --- Models ---
    @Query("SELECT * FROM imported_models ORDER BY isSelected DESC, importedAt DESC")
    fun observeModels(): Flow<List<ImportedModelEntity>>

    @Query("SELECT * FROM imported_models WHERE isSelected = 1 LIMIT 1")
    fun observeSelectedModel(): Flow<ImportedModelEntity?>

    @Query("SELECT * FROM imported_models WHERE isSelected = 1 LIMIT 1")
    suspend fun getSelectedModel(): ImportedModelEntity?

    @Query("SELECT * FROM imported_models WHERE id = :modelId LIMIT 1")
    suspend fun getModelById(modelId: String): ImportedModelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertModel(model: ImportedModelEntity)

    @Query("UPDATE imported_models SET isSelected = 0")
    suspend fun clearModelSelection()

    @Query("UPDATE imported_models SET isSelected = 1 WHERE id = :modelId")
    suspend fun markModelSelected(modelId: String)

    @Transaction
    suspend fun selectModel(modelId: String) {
        clearModelSelection()
        markModelSelected(modelId)
    }

    @Query("DELETE FROM imported_models WHERE id = :modelId")
    suspend fun deleteModel(modelId: String)

    // --- Jobs ---
    @Query("SELECT * FROM transcription_jobs ORDER BY createdAt DESC")
    fun observeJobs(): Flow<List<TranscriptionJobEntity>>

    @Query("SELECT * FROM transcription_jobs WHERE id = :jobId LIMIT 1")
    fun observeJob(jobId: String): Flow<TranscriptionJobEntity?>

    @Query("SELECT * FROM transcription_jobs WHERE id = :jobId LIMIT 1")
    suspend fun getJob(jobId: String): TranscriptionJobEntity?

    @Query("SELECT * FROM transcription_jobs WHERE status IN ('PREPARING', 'SPLITTING', 'TRANSCRIBING') ORDER BY updatedAt DESC LIMIT 1")
    fun observeActiveJob(): Flow<TranscriptionJobEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJob(job: TranscriptionJobEntity)

    @Update
    suspend fun updateJob(job: TranscriptionJobEntity)

    @Query("DELETE FROM transcription_jobs WHERE id = :jobId")
    suspend fun deleteJob(jobId: String)

    // --- Chunks ---
    @Query("SELECT * FROM audio_chunks WHERE jobId = :jobId ORDER BY chunkIndex ASC")
    fun observeChunksForJob(jobId: String): Flow<List<AudioChunkEntity>>

    @Query("SELECT * FROM audio_chunks WHERE jobId = :jobId ORDER BY chunkIndex ASC")
    suspend fun getChunksForJob(jobId: String): List<AudioChunkEntity>

    @Query("SELECT * FROM audio_chunks WHERE id = :chunkId LIMIT 1")
    suspend fun getChunkById(chunkId: String): AudioChunkEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChunks(chunks: List<AudioChunkEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChunk(chunk: AudioChunkEntity)
}
