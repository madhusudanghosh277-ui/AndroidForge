package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.AutoAwesomeMotion
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.audio.RecorderState
import com.example.data.db.AudioChunkEntity
import com.example.data.db.ImportedModelEntity
import com.example.data.db.JobStatus
import com.example.data.db.ModelFormat
import com.example.data.db.TranscriptionJobEntity
import com.example.data.prefs.TranscriptionSettings
import com.example.service.LivePipelineTelemetry
import com.example.ui.StagedAudio
import com.example.ui.components.ActiveModelStatusPill
import com.example.ui.components.ChunkProgressStrip
import com.example.ui.components.StudioFormatters
import com.example.ui.components.TelemetryBadge
import com.example.ui.components.WaveformTimelineCanvas
import com.example.whisper.ModelInspector
import kotlin.math.ceil
import kotlin.math.roundToInt

private val SUPPORTED_LANGUAGES = listOf(
    "en" to "English",
    "es" to "Spanish",
    "fr" to "French",
    "de" to "German",
    "hi" to "Hindi",
    "ja" to "Japanese",
    "zh" to "Chinese",
    "pt" to "Portuguese",
    "ar" to "Arabic",
    "bn" to "Bengali",
)

@Composable
fun StudioScreen(
    selectedModel: ImportedModelEntity?,
    settings: TranscriptionSettings,
    stagedAudio: StagedAudio?,
    isInspectingAudio: Boolean,
    recorderState: RecorderState,
    activeJob: TranscriptionJobEntity?,
    activeChunks: List<AudioChunkEntity>,
    telemetry: LivePipelineTelemetry,
    recentJobs: List<TranscriptionJobEntity>,
    onPickAudioClick: () -> Unit,
    onToggleRecordClick: () -> Unit,
    onOpenModelsTab: () -> Unit,
    onStagedTitleChange: (String) -> Unit,
    onClearStagedAudio: () -> Unit,
    onStartTranscription: () -> Unit,
    onPauseActiveJob: () -> Unit,
    onCancelActiveJob: () -> Unit,
    onOpenJobDetail: (String) -> Unit,
    onCpuThreadsChange: (Int) -> Unit,
    onChunkDurationChange: (Int) -> Unit,
    onOverlapChange: (Int) -> Unit,
    onVadSplitChange: (Boolean) -> Unit,
    onLanguageChange: (String) -> Unit,
    onTranslateChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column {
                    Text(
                        text = "EchoScribe",
                        style = MaterialTheme.typography.headlineMedium,
                    )
                    Text(
                        text = "On-Device Whisper • Long-Audio CPU Studio",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TelemetryBadge(
                    text = "100% OFFLINE",
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }

            // Active local model pill
            ActiveModelStatusPill(
                selectedModel = selectedModel,
                cpuThreads = settings.cpuThreads,
                onClick = onOpenModelsTab,
            )

            // Input action buttons (File Picker + Mic Record)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Button(
                    onClick = onPickAudioClick,
                    enabled = !recorderState.isRecording && activeJob == null,
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .testTag("pick_audio_button"),
                    shape = MaterialTheme.shapes.medium,
                    contentPadding = PaddingValues(horizontal = 14.dp),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AudioFile,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Select Audio",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                OutlinedButton(
                    onClick = onToggleRecordClick,
                    enabled = activeJob == null,
                    modifier = Modifier
                        .weight(1f)
                        .height(54.dp)
                        .testTag("record_audio_button"),
                    shape = MaterialTheme.shapes.medium,
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (recorderState.isRecording) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.outline,
                    ),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (recorderState.isRecording) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurface,
                    ),
                ) {
                    Icon(
                        imageVector = if (recorderState.isRecording) Icons.Rounded.Stop else Icons.Rounded.Mic,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (recorderState.isRecording) "Stop (${StudioFormatters.formatDurationMs(recorderState.elapsedMs)})" else "Record Mic",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            // Live microphone recording card
            AnimatedVisibility(visible = recorderState.isRecording) {
                LiveRecordingCard(recorderState = recorderState, onStop = onToggleRecordClick)
            }

            // Inspecting audio loading indicator
            AnimatedVisibility(visible = isInspectingAudio) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                        Text(
                            text = "Inspecting audio stream & duration...",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            // Active transcription pipeline card
            if (activeJob != null) {
                ActivePipelineCard(
                    job = activeJob,
                    chunks = activeChunks,
                    telemetry = telemetry,
                    onPause = onPauseActiveJob,
                    onCancel = onCancelActiveJob,
                    onOpenDetail = { onOpenJobDetail(activeJob.id) },
                )
            } else if (stagedAudio != null) {
                StagedAudioSetupCard(
                    stagedAudio = stagedAudio,
                    selectedModel = selectedModel,
                    settings = settings,
                    onTitleChange = onStagedTitleChange,
                    onClear = onClearStagedAudio,
                    onOpenModelsTab = onOpenModelsTab,
                    onStart = onStartTranscription,
                    onCpuThreadsChange = onCpuThreadsChange,
                    onChunkDurationChange = onChunkDurationChange,
                    onOverlapChange = onOverlapChange,
                    onVadSplitChange = onVadSplitChange,
                    onLanguageChange = onLanguageChange,
                    onTranslateChange = onTranslateChange,
                )
            } else if (!recorderState.isRecording && !isInspectingAudio) {
                StudioOverviewCard(
                    hasModel = selectedModel != null && selectedModel.format != ModelFormat.GGML_UNSUPPORTED_RUNTIME.name,
                    recentJobs = recentJobs.take(3),
                    onOpenModelsTab = onOpenModelsTab,
                    onOpenJobDetail = onOpenJobDetail,
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun LiveRecordingCard(
    recorderState: RecorderState,
    onStop: () -> Unit,
) {
    val pulseTransition = rememberInfiniteTransition(label = "rec_pulse")
    val scale by pulseTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "rec_scale",
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.error)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Recording 16kHz Mono PCM",
                    style = MaterialTheme.typography.titleSmall,
                )
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { recorderState.amplitude.coerceIn(0.05f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = MaterialTheme.colorScheme.error,
                )
            }
            Text(
                text = StudioFormatters.formatDurationMs(recorderState.elapsedMs),
                style = MaterialTheme.typography.labelMedium,
            )
            TextButton(onClick = onStop) {
                Text("Done")
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StagedAudioSetupCard(
    stagedAudio: StagedAudio,
    selectedModel: ImportedModelEntity?,
    settings: TranscriptionSettings,
    onTitleChange: (String) -> Unit,
    onClear: () -> Unit,
    onOpenModelsTab: () -> Unit,
    onStart: () -> Unit,
    onCpuThreadsChange: (Int) -> Unit,
    onChunkDurationChange: (Int) -> Unit,
    onOverlapChange: (Int) -> Unit,
    onVadSplitChange: (Boolean) -> Unit,
    onLanguageChange: (String) -> Unit,
    onTranslateChange: (Boolean) -> Unit,
) {
    val durationMs = stagedAudio.inspection.durationMs
    val stepSec = (settings.chunkDurationSec - settings.overlapSec).coerceAtLeast(5)
    val estimatedChunks = if (durationMs > 0L) {
        ceil((durationMs / 1000.0) / stepSec.toDouble()).toInt().coerceAtLeast(1)
    } else 1

    val modelReady = selectedModel != null &&
        selectedModel.format != ModelFormat.GGML_UNSUPPORTED_RUNTIME.name

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.GraphicEq,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = "Ready to Split & Transcribe",
                        style = MaterialTheme.typography.titleLarge,
                    )
                }
                IconButton(onClick = onClear) {
                    Icon(Icons.Rounded.Close, contentDescription = "Clear selected audio")
                }
            }

            OutlinedTextField(
                value = stagedAudio.title,
                onValueChange = onTitleChange,
                label = { Text("Transcript Title") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("staged_title_input"),
            )

            // Audio split preview box
            Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surfaceVariant,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = stagedAudio.inspection.displayName,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (durationMs > 0L) StudioFormatters.formatCompactDuration(durationMs) else "Unknown length",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    Text(
                        text = "Split plan: ~$estimatedChunks pieces × ${settings.chunkDurationSec}s (${settings.overlapSec}s overlap) • ${stagedAudio.inspection.sampleRateHz}Hz -> 16kHz mono",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Chunk size selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Piece Length (for low-RAM CPU execution)",
                    style = MaterialTheme.typography.titleSmall,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 20, 30).forEach { sec ->
                        FilterChip(
                            selected = settings.chunkDurationSec == sec,
                            onClick = { onChunkDurationChange(sec) },
                            label = { Text("${sec}s") },
                        )
                    }
                }
            }

            // Overlap selector
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Overlap Padding (prevents cut words at boundaries)",
                    style = MaterialTheme.typography.titleSmall,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 2, 4).forEach { sec ->
                        FilterChip(
                            selected = settings.overlapSec == sec,
                            onClick = { onOverlapChange(sec) },
                            label = { Text(if (sec == 0) "None" else "${sec}s overlap") },
                        )
                    }
                }
            }

            // Silence boundary snapping toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Silence-Aware Split Snap", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Splits on natural pauses within ±1.5s of boundary",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = settings.vadSplitEnabled,
                    onCheckedChange = onVadSplitChange,
                )
            }

            // CPU Threads slider
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.secondary,
                        )
                        Text("CPU Threads", style = MaterialTheme.typography.titleSmall)
                    }
                    Text(
                        text = "${settings.cpuThreads} threads",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary,
                    )
                }
                Slider(
                    value = settings.cpuThreads.toFloat(),
                    onValueChange = { onCpuThreadsChange(it.roundToInt()) },
                    valueRange = 1f..8f,
                    steps = 6,
                )
            }

            // Language selection
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Spoken Language", style = MaterialTheme.typography.titleSmall)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    SUPPORTED_LANGUAGES.forEach { (code, label) ->
                        FilterChip(
                            selected = settings.languageCode == code,
                            onClick = { onLanguageChange(code) },
                            label = { Text(label) },
                        )
                    }
                }
            }

            if (selectedModel?.multilingual == true && settings.languageCode != "en") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Translate to English", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Outputs English text directly via Whisper",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = settings.translateToEnglish,
                        onCheckedChange = onTranslateChange,
                    )
                }
            }

            if (modelReady) {
                Button(
                    onClick = onStart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("start_transcription_button"),
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Split & Transcribe Locally on CPU")
                }
            } else {
                OutlinedButton(
                    onClick = onOpenModelsTab,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("import_model_first_button"),
                    shape = MaterialTheme.shapes.medium,
                ) {
                    Text("Import a Local .tflite or .onnx Model First")
                }
            }
        }
    }
}

@Composable
private fun ActivePipelineCard(
    job: TranscriptionJobEntity,
    chunks: List<AudioChunkEntity>,
    telemetry: LivePipelineTelemetry,
    onPause: () -> Unit,
    onCancel: () -> Unit,
    onOpenDetail: () -> Unit,
) {
    val total = job.totalChunks.coerceAtLeast(telemetry.totalChunks).coerceAtLeast(1)
    val progress = if (job.status == JobStatus.SPLITTING.name) {
        telemetry.splitProgress.coerceIn(0f, 1f)
    } else {
        (job.completedChunks.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = job.title,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = telemetry.phaseLabel.ifBlank { "Processing on ${job.cpuThreads} CPU threads..." },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                TelemetryBadge(
                    text = "${(progress * 100).toInt()}%",
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }

            WaveformTimelineCanvas(
                peaks = StudioFormatters.parsePeaks(job.waveformPeaksCsv),
                progressFraction = progress,
            )

            ChunkProgressStrip(chunks = chunks)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TelemetryBadge(text = "${job.completedChunks}/$total pieces")
                if (telemetry.realTimeFactor > 0f) {
                    TelemetryBadge(text = "%.2fx RTF".format(telemetry.realTimeFactor))
                }
                if (telemetry.estimatedRemainingMs > 0L) {
                    TelemetryBadge(text = "ETA ${StudioFormatters.formatCompactDuration(telemetry.estimatedRemainingMs)}")
                }
            }

            if (job.stitchedTranscript.isNotBlank()) {
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "LIVE CONNECTED TRANSCRIPT",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = job.stitchedTranscript.takeLast(320),
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 5,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedButton(
                    onClick = onPause,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                ) {
                    Icon(Icons.Rounded.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Pause")
                }
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Cancel")
                }
                TextButton(
                    onClick = onOpenDetail,
                    modifier = Modifier.height(48.dp),
                ) {
                    Text("Details")
                }
            }
        }
    }
}

@Composable
private fun StudioOverviewCard(
    hasModel: Boolean,
    recentJobs: List<TranscriptionJobEntity>,
    onOpenModelsTab: () -> Unit,
    onOpenJobDetail: (String) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
                painter = painterResource(id = R.drawable.img_studio_waveform_hero),
                contentDescription = "EchoScribe acoustic waveform analyzer",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentScale = ContentScale.Crop,
            )

            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = "Long-Audio Local CPU Pipeline",
                    style = MaterialTheme.typography.titleLarge,
                )
                Text(
                    text = "Feed 30-minute+ podcasts, lectures, or meetings. EchoScribe streams audio to 16kHz PCM, splits on natural pauses with overlap, runs your imported Whisper model piece-by-piece on CPU, and stitches a seamless transcript.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    StepPill("1. Import Model", Modifier.weight(1f))
                    StepPill("2. Auto-Split", Modifier.weight(1f))
                    StepPill("3. Stitch Text", Modifier.weight(1f))
                }

                if (!hasModel) {
                    Button(
                        onClick = onOpenModelsTab,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("overview_import_model_button"),
                    ) {
                        Icon(Icons.Rounded.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Import Small Local Model (.tflite / .onnx)")
                    }
                }
            }

            if (recentJobs.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = "RECENT TRANSCRIPTIONS",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    recentJobs.forEach { job ->
                        Surface(
                            onClick = { onOpenJobDetail(job.id) },
                            shape = MaterialTheme.shapes.small,
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = job.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = "${StudioFormatters.formatCompactDuration(job.totalDurationMs)} • ${job.completedChunks}/${job.totalChunks} pieces",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                TelemetryBadge(text = job.status)
                            }
                        }
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(6.dp))
            }
        }
    }
}

@Composable
private fun StepPill(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.AutoAwesomeMotion,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
