package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightStudioColorScheme = lightColorScheme(
    primary = SignalCoral,
    onPrimary = Color.White,
    primaryContainer = SignalCoralContainer,
    onPrimaryContainer = SignalCoralDarkText,
    secondary = AcousticTeal,
    onSecondary = Color.White,
    secondaryContainer = AcousticTealContainer,
    onSecondaryContainer = AcousticTealDarkText,
    tertiary = TelemetryBlue,
    onTertiary = Color.White,
    tertiaryContainer = TelemetryBlueContainer,
    onTertiaryContainer = TelemetryBlueDarkText,
    background = StudioPaper,
    onBackground = StudioInk,
    surface = StudioCard,
    onSurface = StudioInk,
    surfaceVariant = StudioSurfaceMuted,
    onSurfaceVariant = StudioSlate,
    surfaceContainerLow = StudioPaper,
    surfaceContainer = StudioSurfaceMuted,
    surfaceContainerHigh = StudioSurfaceHigh,
    outline = StudioOutline,
    outlineVariant = StudioOutlineSubtle,
    error = AlertRed,
    onError = Color.White,
    errorContainer = AlertRedContainer,
)

private val DarkStudioColorScheme = darkColorScheme(
    primary = DarkSignalCoral,
    onPrimary = Color(0xFF1A0904),
    primaryContainer = DarkSignalCoralContainer,
    onPrimaryContainer = Color(0xFFFFD8CB),
    secondary = DarkAcousticTeal,
    onSecondary = Color(0xFF042623),
    secondaryContainer = DarkAcousticTealContainer,
    onSecondaryContainer = Color(0xFFA7F3D0),
    tertiary = DarkTelemetryBlue,
    onTertiary = Color(0xFF0A1B36),
    tertiaryContainer = DarkTelemetryBlueContainer,
    onTertiaryContainer = Color(0xFFBFDBFE),
    background = DarkStudioBg,
    onBackground = DarkStudioInk,
    surface = DarkStudioCard,
    onSurface = DarkStudioInk,
    surfaceVariant = DarkStudioSurfaceMuted,
    onSurfaceVariant = DarkStudioSlate,
    surfaceContainerLow = DarkStudioBg,
    surfaceContainer = DarkStudioCard,
    surfaceContainerHigh = DarkStudioSurfaceHigh,
    outline = DarkStudioOutline,
    outlineVariant = DarkStudioSurfaceHigh,
    error = Color(0xFFF87171),
    onError = Color(0xFF3B0A0A),
    errorContainer = Color(0xFF5C1515),
)

val EchoScribeShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun EchoScribeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkStudioColorScheme else LightStudioColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = EchoScribeTypography,
        shapes = EchoScribeShapes,
        content = content,
    )
}
