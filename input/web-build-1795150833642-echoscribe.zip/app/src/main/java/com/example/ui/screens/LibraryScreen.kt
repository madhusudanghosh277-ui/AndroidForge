package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.db.JobStatus
import com.example.data.db.TranscriptionJobEntity
import com.example.ui.components.StudioFormatters
import com.example.ui.components.TelemetryBadge
import com.example.ui.components.WaveformTimelineCanvas

@Composable
fun LibraryScreen(
    jobs: List<TranscriptionJobEntity>,
    onOpenJobDetail: (String) -> Unit,
    onResumeJob: (String) -> Unit,
    onDeleteJob: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredJobs = remember(jobs, searchQuery) {
        if (searchQuery.isBlank()) jobs
        else {
            val q = searchQuery.trim().lowercase()
            jobs.filter {
                it.title.lowercase().contains(q) ||
                    it.stitchedTranscript.lowercase().contains(q) ||
                    it.sourceFileName.lowercase().contains(q)
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 680.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Transcripts",
                        style = MaterialTheme.typography.headlineMedium,
                    )
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search transcripts or file names...") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("transcript_search_input"),
                    )
                }
            }

            if (filteredJobs.isEmpty()) {
                item {
                    Surface(
                        shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Description,
                                contentDescription = null,
                                modifier = Modifier.size(36.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Text(
                                text = if (jobs.isEmpty()) "No Transcriptions Yet" else "No Matching Transcripts",
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Text(
                                text = if (jobs.isEmpty()) {
                                    "Select an audio file or record audio in the Transcribe tab to split long recordings and stitch local transcripts."
                                } else {
                                    "Try clearing your search filter."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            } else {
                items(filteredJobs, key = { it.id }) { job ->
                    TranscriptJobCard(
                        job = job,
                        onClick = { onOpenJobDetail(job.id) },
                        onResume = { onResumeJob(job.id) },
                        onDelete = { onDeleteJob(job.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun TranscriptJobCard(
    job: TranscriptionJobEntity,
    onClick: () -> Unit,
    onResume: () -> Unit,
    onDelete: () -> Unit,
) {
    val total = job.totalChunks.coerceAtLeast(1)
    val progress = (job.completedChunks.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val canResume = job.status == JobStatus.PAUSED.name ||
        job.status == JobStatus.FAILED.name ||
        job.status == JobStatus.CANCELLED.name

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("job_card_${job.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = job.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${StudioFormatters.formatCompactDuration(job.totalDurationMs)} • ${job.completedChunks}/$total pieces • ${job.modelName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))
                TelemetryBadge(
                    text = job.status,
                    containerColor = when (job.status) {
                        JobStatus.COMPLETED.name -> MaterialTheme.colorScheme.secondaryContainer
                        JobStatus.TRANSCRIBING.name, JobStatus.SPLITTING.name -> MaterialTheme.colorScheme.primaryContainer
                        JobStatus.FAILED.name -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    },
                    contentColor = when (job.status) {
                        JobStatus.COMPLETED.name -> MaterialTheme.colorScheme.onSecondaryContainer
                        JobStatus.TRANSCRIBING.name, JobStatus.SPLITTING.name -> MaterialTheme.colorScheme.onPrimaryContainer
                        JobStatus.FAILED.name -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }

            WaveformTimelineCanvas(
                peaks = StudioFormatters.parsePeaks(job.waveformPeaksCsv),
                progressFraction = progress,
                modifier = Modifier.height(30.dp),
            )

            if (job.stitchedTranscript.isNotBlank()) {
                Text(
                    text = job.stitchedTranscript,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            } else if (!job.errorMessage.isNullOrBlank()) {
                Text(
                    text = job.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (canResume && job.totalChunks > 0) {
                    OutlinedButton(
                        onClick = onResume,
                        modifier = Modifier.height(40.dp),
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Resume")
                    }
                } else {
                    Text(
                        text = "${job.chunkDurationSec}s pieces • ${job.overlapSec}s overlap",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete transcript ${job.title}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
