package com.example.whisper

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import com.example.audio.WhisperAudioProcessor
import com.example.data.db.ImportedModelEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.nio.LongBuffer

/**
 * Runs Whisper .onnx models locally on CPU via Microsoft ONNX Runtime Android.
 * Supports both single-file end-to-end Whisper ONNX and split encoder.onnx + decoder.onnx models.
 */
class OnnxWhisperEngine : WhisperEngine {
    private var env: OrtEnvironment? = null
    private var primarySession: OrtSession? = null
    private var decoderSession: OrtSession? = null
    private var tokenizer: WhisperTokenizer = WhisperTokenizer()

    override suspend fun load(model: ImportedModelEntity, cpuThreads: Int) = withContext(Dispatchers.Default) {
        release()
        val primaryFile = File(model.primaryPath)
        require(primaryFile.exists()) { "ONNX model file not found at ${model.primaryPath}" }

        tokenizer = WhisperTokenizer.loadFromFile(model.vocabPath)
        val ortEnv = OrtEnvironment.getEnvironment()
        env = ortEnv

        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(cpuThreads.coerceIn(1, 8))
            setInterOpNumThreads(1)
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }

        primarySession = ortEnv.createSession(model.primaryPath, opts)
        val decPath = model.decoderPath
        if (!decPath.isNullOrBlank() && File(decPath).exists()) {
            decoderSession = ortEnv.createSession(decPath, opts)
        }
    }

    override suspend fun transcribeChunk(
        pcm16: ShortArray,
        languageCode: String,
        translateToEnglish: Boolean,
    ): WhisperChunkResult = withContext(Dispatchers.Default) {
        val ortEnv = env ?: error("ONNX environment not initialized.")
        val session = primarySession ?: error("ONNX primary session not loaded.")

        val startNs = System.nanoTime()
        val tokenIds = if (decoderSession != null) {
            runEncoderDecoder(ortEnv, session, decoderSession!!, pcm16, languageCode, translateToEnglish)
        } else {
            runSingleSession(ortEnv, session, pcm16)
        }

        val text = tokenizer.decodeTokens(tokenIds)
        val elapsedMs = (System.nanoTime() - startNs) / 1_000_000L

        WhisperChunkResult(
            text = text,
            inferenceMs = elapsedMs.coerceAtLeast(1L),
            tokenCount = tokenIds.size,
        )
    }

    private fun runSingleSession(
        ortEnv: OrtEnvironment,
        session: OrtSession,
        pcm16: ShortArray,
    ): IntArray {
        val inputInfo = session.inputInfo
        val primaryName = inputInfo.keys.firstOrNull() ?: "input_features"
        val nodeInfo = inputInfo[primaryName]?.info as? TensorInfo
        val shape = nodeInfo?.shape ?: longArrayOf(1L, 80L, 3000L)

        val inputTensor = if (shape.size == 2 && shape[1] == WhisperAudioProcessor.N_SAMPLES.toLong()) {
            val raw = WhisperAudioProcessor.pcm16ToPaddedFloat32(pcm16)
            OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(raw), longArrayOf(1L, raw.size.toLong()))
        } else {
            val mel = WhisperAudioProcessor.computeLogMelSpectrogram(pcm16)
            OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(mel), longArrayOf(1L, 80L, 3000L))
        }

        val inputs = HashMap<String, OnnxTensor>()
        inputs[primaryName] = inputTensor

        // Supply optional scalar/beam parameters if exported inside single-file Whisper ONNX
        for ((name, info) in inputInfo) {
            if (name == primaryName) continue
            val tInfo = info.info as? TensorInfo ?: continue
            val tShape = tInfo.shape.map { if (it <= 0L) 1L else it }.toLongArray()
            val elemCount = tShape.fold(1L) { acc, d -> acc * d }.toInt()
            val tensor = when (tInfo.type) {
                ai.onnxruntime.OnnxJavaType.INT32 -> {
                    val data = IntArray(elemCount) {
                        when {
                            name.contains("max_length") -> 224
                            name.contains("min_length") -> 0
                            name.contains("num_beams") -> 1
                            name.contains("num_return") -> 1
                            else -> 0
                        }
                    }
                    OnnxTensor.createTensor(ortEnv, IntBuffer.wrap(data), tShape)
                }
                ai.onnxruntime.OnnxJavaType.FLOAT -> {
                    val data = FloatArray(elemCount) { if (name.contains("length_penalty")) 1.0f else 0f }
                    OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(data), tShape)
                }
                else -> null
            }
            if (tensor != null) inputs[name] = tensor
        }

        try {
            session.run(inputs).use { results ->
                val outVal = results[0].value
                return flattenToIntArray(outVal)
            }
        } finally {
            inputs.values.forEach { runCatching { it.close() } }
        }
    }

    private fun runEncoderDecoder(
        ortEnv: OrtEnvironment,
        encoder: OrtSession,
        decoder: OrtSession,
        pcm16: ShortArray,
        languageCode: String,
        translateToEnglish: Boolean,
    ): IntArray {
        val mel = WhisperAudioProcessor.computeLogMelSpectrogram(pcm16)
        val encInputName = encoder.inputInfo.keys.firstOrNull() ?: "input_features"
        val melTensor = OnnxTensor.createTensor(
            ortEnv,
            FloatBuffer.wrap(mel),
            longArrayOf(1L, 80L, 3000L),
        )

        val encoderOutData: Array<*>?
        var encoderHiddenTensor: OnnxTensor? = null
        try {
            encoder.run(mapOf(encInputName to melTensor)).use { encResults ->
                val firstOut = encResults[0] as OnnxTensor
                val info = firstOut.info as TensorInfo
                val hiddenShape = info.shape
                val flatFloats = FloatArray(firstOut.floatBuffer.remaining()).also {
                    firstOut.floatBuffer.get(it)
                }
                encoderHiddenTensor = OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(flatFloats), hiddenShape)
            }
        } finally {
            melTensor.close()
        }

        val hiddenTensor = encoderHiddenTensor ?: return IntArray(0)
        val langId = WhisperTokenizer.languageTokenId(languageCode) ?: 50259
        val taskId = if (translateToEnglish) WhisperTokenizer.TOKEN_TRANSLATE else WhisperTokenizer.TOKEN_TRANSCRIBE

        val promptTokens = mutableListOf(
            WhisperTokenizer.TOKEN_SOT,
            langId,
            taskId,
            WhisperTokenizer.TOKEN_NO_TIMESTAMPS,
        )
        val generated = mutableListOf<Int>()

        val decInputNames = decoder.inputInfo.keys.toList()
        val idsName = decInputNames.firstOrNull { it.contains("input_ids") || it.contains("tokens") }
            ?: decInputNames.first()
        val encStateName = decInputNames.firstOrNull {
            it.contains("encoder") || it.contains("hidden") || it.contains("audio")
        } ?: decInputNames.last()

        val idTensorInfo = decoder.inputInfo[idsName]?.info as? TensorInfo
        val useInt32Ids = idTensorInfo?.type == ai.onnxruntime.OnnxJavaType.INT32

        try {
            val maxTokens = 160
            for (step in 0 until maxTokens) {
                val idsTensor = if (useInt32Ids) {
                    val arr = promptTokens.toIntArray()
                    OnnxTensor.createTensor(ortEnv, IntBuffer.wrap(arr), longArrayOf(1L, arr.size.toLong()))
                } else {
                    val arr = LongArray(promptTokens.size) { promptTokens[it].toLong() }
                    OnnxTensor.createTensor(ortEnv, LongBuffer.wrap(arr), longArrayOf(1L, arr.size.toLong()))
                }

                val decInputs = mapOf(
                    idsName to idsTensor,
                    encStateName to hiddenTensor,
                )

                val nextToken = try {
                    decoder.run(decInputs).use { decResults ->
                        val logitsTensor = decResults[0] as OnnxTensor
                        val logitsInfo = logitsTensor.info as TensorInfo
                        val shape = logitsInfo.shape
                        val vocabSize = shape.last().toInt()
                        val seqLen = if (shape.size >= 2) shape[shape.size - 2].toInt() else 1
                        val fb = logitsTensor.floatBuffer
                        val lastStepOffset = (seqLen - 1) * vocabSize
                        fb.position(lastStepOffset)
                        var bestIdx = WhisperTokenizer.TOKEN_EOT
                        var bestLogit = -Float.MAX_VALUE
                        for (v in 0 until vocabSize) {
                            val valLogit = fb.get()
                            if (valLogit > bestLogit) {
                                bestLogit = valLogit
                                bestIdx = v
                            }
                        }
                        bestIdx
                    }
                } finally {
                    idsTensor.close()
                }

                if (nextToken == WhisperTokenizer.TOKEN_EOT) break
                promptTokens.add(nextToken)
                generated.add(nextToken)
            }
        } finally {
            hiddenTensor.close()
        }

        return generated.toIntArray()
    }

    private fun flattenToIntArray(value: Any?): IntArray {
        val out = mutableListOf<Int>()
        fun collect(node: Any?) {
            when (node) {
                is IntArray -> node.forEach { out.add(it) }
                is LongArray -> node.forEach { out.add(it.toInt()) }
                is FloatArray -> node.forEach { out.add(it.toInt()) }
                is Array<*> -> node.forEach { collect(it) }
            }
        }
        collect(value)
        return out.toIntArray()
    }

    override suspend fun release() = withContext(Dispatchers.Default) {
        runCatching { primarySession?.close() }
        runCatching { decoderSession?.close() }
        runCatching { env?.close() }
        primarySession = null
        decoderSession = null
        env = null
    }
}
