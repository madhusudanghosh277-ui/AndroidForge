package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioInspection
import com.example.audio.AudioRecorderManager
import com.example.audio.AudioSplitter
import com.example.audio.RecorderState
import com.example.data.db.AudioChunkEntity
import com.example.data.db.EchoScribeDatabase
import com.example.data.db.ImportedModelEntity
import com.example.data.db.ModelFormat
import com.example.data.db.TranscriptionJobEntity
import com.example.data.prefs.TranscriptionSettings
import com.example.data.prefs.UserPreferencesRepository
import com.example.data.repo.ImportResult
import com.example.data.repo.ModelRepository
import com.example.data.repo.TranscriptionRepository
import com.example.service.LivePipelineTelemetry
import com.example.service.PipelineTelemetryBus
import com.example.service.WhisperTranscriptionService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class StagedAudio(
    val uri: Uri,
    val inspection: AudioInspection,
    val title: String,
)

class EchoScribeViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = EchoScribeDatabase.getInstance(application).echoScribeDao()
    private val modelRepo = ModelRepository(application, dao)
    private val transcriptionRepo = TranscriptionRepository(application, dao)
    private val prefsRepo = UserPreferencesRepository(application)
    private val recorderManager = AudioRecorderManager(application)

    val models: StateFlow<List<ImportedModelEntity>> = modelRepo.models
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedModel: StateFlow<ImportedModelEntity?> = modelRepo.selectedModel
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val settings: StateFlow<TranscriptionSettings> = prefsRepo.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TranscriptionSettings())

    val jobs: StateFlow<List<TranscriptionJobEntity>> = transcriptionRepo.jobs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeJob: StateFlow<TranscriptionJobEntity?> = transcriptionRepo.activeJob
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeJobChunks: StateFlow<List<AudioChunkEntity>> = activeJob
        .flatMapLatest { job ->
            if (job == null) flowOf(emptyList()) else transcriptionRepo.observeChunks(job.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val telemetry: StateFlow<LivePipelineTelemetry> = PipelineTelemetryBus.telemetry
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), LivePipelineTelemetry())

    val recorderState: StateFlow<RecorderState> = recorderManager.state

    private val _stagedAudio = MutableStateFlow<StagedAudio?>(null)
    val stagedAudio: StateFlow<StagedAudio?> = _stagedAudio.asStateFlow()

    private val _isInspectingAudio = MutableStateFlow(false)
    val isInspectingAudio: StateFlow<Boolean> = _isInspectingAudio.asStateFlow()

    private val _isImportingModel = MutableStateFlow(false)
    val isImportingModel: StateFlow<Boolean> = _isImportingModel.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    init {
        viewModelScope.launch {
            recorderManager.state.collect { state ->
                val uri = state.recordedFileUri
                if (!state.isRecording && uri != null) {
                    recorderManager.clearRecordedUri()
                    stageAudioUri(uri)
                }
                if (state.errorMessage != null) {
                    _snackbarMessages.tryEmit(state.errorMessage)
                }
            }
        }
    }

    fun observeJob(jobId: String): Flow<TranscriptionJobEntity?> = transcriptionRepo.observeJob(jobId)

    fun observeChunks(jobId: String): Flow<List<AudioChunkEntity>> = transcriptionRepo.observeChunks(jobId)

    fun stageAudioUri(uri: Uri) {
        viewModelScope.launch {
            _isInspectingAudio.value = true
            try {
                runCatching {
                    getApplication<Application>().contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                val info = AudioSplitter.inspectAudio(getApplication(), uri)
                val defaultTitle = info.displayName.substringBeforeLast('.').ifBlank { "Audio Transcript" }
                _stagedAudio.value = StagedAudio(
                    uri = uri,
                    inspection = info,
                    title = defaultTitle,
                )
            } catch (e: Exception) {
                _snackbarMessages.tryEmit("Could not read audio file: ${e.message}")
            } finally {
                _isInspectingAudio.value = false
            }
        }
    }

    fun updateStagedTitle(newTitle: String) {
        _stagedAudio.value = _stagedAudio.value?.copy(title = newTitle)
    }

    fun clearStagedAudio() {
        _stagedAudio.value = null
    }

    fun startRecording() {
        recorderManager.startRecording(viewModelScope)
    }

    fun stopRecording() {
        recorderManager.stopRecording()
    }

    fun startTranscription() {
        val staged = _stagedAudio.value ?: return
        val model = selectedModel.value
        if (model == null) {
            _snackbarMessages.tryEmit("Import and select a local Whisper model (.tflite or .onnx) first.")
            return
        }
        if (model.format == ModelFormat.GGML_UNSUPPORTED_RUNTIME.name) {
            _snackbarMessages.tryEmit("GGML .bin cannot run on this runtime. Select a .tflite or .onnx model.")
            return
        }

        val currentSettings = settings.value
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, WhisperTranscriptionService::class.java).apply {
            action = WhisperTranscriptionService.ACTION_START_NEW
            putExtra(WhisperTranscriptionService.EXTRA_URI, staged.uri.toString())
            putExtra(WhisperTranscriptionService.EXTRA_TITLE, staged.title.ifBlank { staged.inspection.displayName })
            putExtra(WhisperTranscriptionService.EXTRA_FILENAME, staged.inspection.displayName)
            putExtra(WhisperTranscriptionService.EXTRA_DURATION_MS, staged.inspection.durationMs)
            putExtra(WhisperTranscriptionService.EXTRA_SAMPLE_RATE, staged.inspection.sampleRateHz)
            putExtra(WhisperTranscriptionService.EXTRA_MODEL_ID, model.id)
            putExtra(WhisperTranscriptionService.EXTRA_CHUNK_SEC, currentSettings.chunkDurationSec)
            putExtra(WhisperTranscriptionService.EXTRA_OVERLAP_SEC, currentSettings.overlapSec)
            putExtra(WhisperTranscriptionService.EXTRA_VAD_SPLIT, currentSettings.vadSplitEnabled)
            putExtra(WhisperTranscriptionService.EXTRA_CPU_THREADS, currentSettings.cpuThreads)
            putExtra(WhisperTranscriptionService.EXTRA_LANGUAGE, currentSettings.languageCode)
            putExtra(WhisperTranscriptionService.EXTRA_TRANSLATE, currentSettings.translateToEnglish)
        }
        startForegroundServiceCompat(intent)
        _stagedAudio.value = null
    }

    fun pauseActiveJob() {
        val ctx = getApplication<Application>()
        ctx.startService(
            Intent(ctx, WhisperTranscriptionService::class.java).apply {
                action = WhisperTranscriptionService.ACTION_PAUSE
            }
        )
    }

    fun cancelActiveJob() {
        val ctx = getApplication<Application>()
        ctx.startService(
            Intent(ctx, WhisperTranscriptionService::class.java).apply {
                action = WhisperTranscriptionService.ACTION_CANCEL
            }
        )
    }

    fun resumeJob(jobId: String, singleChunkId: String? = null) {
        val ctx = getApplication<Application>()
        val intent = Intent(ctx, WhisperTranscriptionService::class.java).apply {
            action = WhisperTranscriptionService.ACTION_RESUME_JOB
            putExtra(WhisperTranscriptionService.EXTRA_JOB_ID, jobId)
            if (singleChunkId != null) {
                putExtra(WhisperTranscriptionService.EXTRA_CHUNK_ID, singleChunkId)
            }
        }
        startForegroundServiceCompat(intent)
    }

    fun importModelFile(uri: Uri) {
        viewModelScope.launch {
            _isImportingModel.value = true
            try {
                when (val result = modelRepo.importModelFromUri(uri)) {
                    is ImportResult.Success -> {
                        val msg = result.warning ?: "Imported ${result.model.name} (${result.model.sizeTier})"
                        _snackbarMessages.tryEmit(msg)
                    }
                    is ImportResult.Error -> _snackbarMessages.tryEmit(result.message)
                }
            } finally {
                _isImportingModel.value = false
            }
        }
    }

    fun attachVocabFile(modelId: String, uri: Uri) {
        viewModelScope.launch {
            _isImportingModel.value = true
            try {
                when (val result = modelRepo.attachVocabToModel(modelId, uri)) {
                    is ImportResult.Success -> _snackbarMessages.tryEmit("Attached vocabulary: ${result.model.vocabFileName}")
                    is ImportResult.Error -> _snackbarMessages.tryEmit(result.message)
                }
            } finally {
                _isImportingModel.value = false
            }
        }
    }

    fun attachDecoderFile(modelId: String, uri: Uri) {
        viewModelScope.launch {
            _isImportingModel.value = true
            try {
                when (val result = modelRepo.attachDecoderOnnxToModel(modelId, uri)) {
                    is ImportResult.Success -> _snackbarMessages.tryEmit("Attached decoder ONNX to ${result.model.name}")
                    is ImportResult.Error -> _snackbarMessages.tryEmit(result.message)
                }
            } finally {
                _isImportingModel.value = false
            }
        }
    }

    fun selectModel(modelId: String) {
        viewModelScope.launch {
            modelRepo.selectModel(modelId)
        }
    }

    fun deleteModel(modelId: String) {
        viewModelScope.launch {
            modelRepo.deleteModel(modelId)
            _snackbarMessages.tryEmit("Model removed from local storage.")
        }
    }

    fun deleteJob(jobId: String) {
        viewModelScope.launch {
            transcriptionRepo.deleteJob(jobId)
            _snackbarMessages.tryEmit("Transcript deleted.")
        }
    }

    fun updateChunkText(chunkId: String, newText: String) {
        viewModelScope.launch {
            transcriptionRepo.updateChunkTextAndRestitch(chunkId, newText)
            _snackbarMessages.tryEmit("Chunk updated and transcript re-stitched.")
        }
    }

    suspend fun buildExportText(jobId: String, format: String): String {
        return transcriptionRepo.buildExportContent(jobId, format)
    }

    fun setCpuThreads(threads: Int) = viewModelScope.launch { prefsRepo.setCpuThreads(threads) }
    fun setChunkDurationSec(sec: Int) = viewModelScope.launch { prefsRepo.setChunkDurationSec(sec) }
    fun setOverlapSec(sec: Int) = viewModelScope.launch { prefsRepo.setOverlapSec(sec) }
    fun setVadSplitEnabled(enabled: Boolean) = viewModelScope.launch { prefsRepo.setVadSplitEnabled(enabled) }
    fun setLanguageCode(code: String) = viewModelScope.launch { prefsRepo.setLanguageCode(code) }
    fun setTranslateToEnglish(translate: Boolean) = viewModelScope.launch { prefsRepo.setTranslateToEnglish(translate) }

    private fun startForegroundServiceCompat(intent: Intent) {
        val ctx = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(intent)
        } else {
            ctx.startService(intent)
        }
    }
}
