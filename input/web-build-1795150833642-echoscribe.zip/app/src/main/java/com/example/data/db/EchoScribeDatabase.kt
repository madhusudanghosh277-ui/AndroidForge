package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ImportedModelEntity::class,
        TranscriptionJobEntity::class,
        AudioChunkEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class EchoScribeDatabase : RoomDatabase() {
    abstract fun echoScribeDao(): EchoScribeDao

    companion object {
        @Volatile
        private var INSTANCE: EchoScribeDatabase? = null

        fun getInstance(context: Context): EchoScribeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    EchoScribeDatabase::class.java,
                    "echoscribe_local.db",
                ).build().also { INSTANCE = it }
            }
        }
    }
}
