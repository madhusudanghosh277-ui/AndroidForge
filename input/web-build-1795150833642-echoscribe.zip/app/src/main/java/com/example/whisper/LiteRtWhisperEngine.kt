package com.example.whisper

import com.example.audio.WhisperAudioProcessor
import com.example.data.db.ImportedModelEntity
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import com.google.ai.edge.litert.Environment
import com.google.ai.edge.litert.TensorBuffer
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

/**
 * Runs Whisper .tflite models locally on the mobile CPU via Google AI Edge LiteRT CompiledModel.
 * Strictly confines create(), run(), and close() to a single dedicated background thread.
 */
class LiteRtWhisperEngine : WhisperEngine {
    private val engineDispatcher: ExecutorCoroutineDispatcher =
        Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "EchoScribe-LiteRT-CPU").apply { isDaemon = true }
        }.asCoroutineDispatcher()

    private var env: Environment? = null
    private var compiledModel: CompiledModel? = null
    private var inputBuffers: List<TensorBuffer> = emptyList()
    private var outputBuffers: List<TensorBuffer> = emptyList()
    private var tokenizer: WhisperTokenizer = WhisperTokenizer()
    private var expectsRawPcmInput: Boolean? = null

    override suspend fun load(model: ImportedModelEntity, cpuThreads: Int) {
        withContext(engineDispatcher) {
            releaseInternal()

            val modelFile = File(model.primaryPath)
            require(modelFile.exists()) { "Model file not found at ${model.primaryPath}" }

            tokenizer = WhisperTokenizer.loadFromFile(model.vocabPath)
            val createdEnv = Environment.create()
            env = createdEnv

            val options = CompiledModel.Options(Accelerator.CPU).apply {
                cpuOptions = CompiledModel.CpuOptions(
                    numThreads = cpuThreads.coerceIn(1, 8),
                )
            }

            val loaded = CompiledModel.create(model.primaryPath, options, createdEnv)
            compiledModel = loaded
            inputBuffers = loaded.createInputBuffers()
            outputBuffers = loaded.createOutputBuffers()
            expectsRawPcmInput = null
        }
    }

    override suspend fun transcribeChunk(
        pcm16: ShortArray,
        languageCode: String,
        translateToEnglish: Boolean,
    ): WhisperChunkResult = withContext(engineDispatcher) {
        val model = compiledModel ?: error("LiteRT model is not loaded.")
        require(inputBuffers.isNotEmpty() && outputBuffers.isNotEmpty()) {
            "Model buffers are not initialized."
        }

        val startNs = System.nanoTime()

        // Detect whether the .tflite graph accepts [1, 80, 3000] mel features or [1, 480000] raw PCM
        if (expectsRawPcmInput == null) {
            val mel = WhisperAudioProcessor.computeLogMelSpectrogram(pcm16)
            val melWritten = runCatching { inputBuffers[0].writeFloat(mel) }.isSuccess
            if (melWritten) {
                expectsRawPcmInput = false
            } else {
                val raw = WhisperAudioProcessor.pcm16ToPaddedFloat32(pcm16)
                inputBuffers[0].writeFloat(raw)
                expectsRawPcmInput = true
            }
        } else if (expectsRawPcmInput == true) {
            inputBuffers[0].writeFloat(WhisperAudioProcessor.pcm16ToPaddedFloat32(pcm16))
        } else {
            inputBuffers[0].writeFloat(WhisperAudioProcessor.computeLogMelSpectrogram(pcm16))
        }

        // Write optional prompt / language token input if model exposes a 2nd input tensor
        if (inputBuffers.size > 1) {
            val langId = WhisperTokenizer.languageTokenId(languageCode) ?: 50259
            val taskId = if (translateToEnglish) WhisperTokenizer.TOKEN_TRANSLATE else WhisperTokenizer.TOKEN_TRANSCRIBE
            runCatching {
                inputBuffers[1].writeInt(
                    intArrayOf(
                        WhisperTokenizer.TOKEN_SOT,
                        langId,
                        taskId,
                        WhisperTokenizer.TOKEN_NO_TIMESTAMPS,
                    )
                )
            }
        }

        model.run(inputBuffers, outputBuffers)

        val tokenIds = extractTokenIds(outputBuffers[0])
        val text = tokenizer.decodeTokens(tokenIds)
        val elapsedMs = (System.nanoTime() - startNs) / 1_000_000L

        WhisperChunkResult(
            text = text,
            inferenceMs = elapsedMs.coerceAtLeast(1L),
            tokenCount = tokenIds.size,
        )
    }

    private fun extractTokenIds(outputBuffer: TensorBuffer): IntArray {
        val asInt = runCatching { outputBuffer.readInt() }.getOrNull()
        if (asInt != null && asInt.isNotEmpty()) {
            return asInt
        }
        val asLong = runCatching { outputBuffer.readLong() }.getOrNull()
        if (asLong != null && asLong.isNotEmpty()) {
            return IntArray(asLong.size) { asLong[it].toInt() }
        }
        val asFloat = runCatching { outputBuffer.readFloat() }.getOrNull() ?: return IntArray(0)
        // If logits [seqLen * vocabSize] (~51864..51865), take argmax per step
        val vocabCandidates = listOf(51865, 51864, 50364)
        val vocabSize = vocabCandidates.firstOrNull { asFloat.size >= it && asFloat.size % it == 0 }
        if (vocabSize != null) {
            val seqLen = asFloat.size / vocabSize
            return IntArray(seqLen) { step ->
                val offset = step * vocabSize
                var bestIdx = 0
                var bestVal = -Float.MAX_VALUE
                for (v in 0 until vocabSize) {
                    val logit = asFloat[offset + v]
                    if (logit > bestVal) {
                        bestVal = logit
                        bestIdx = v
                    }
                }
                bestIdx
            }
        }
        return IntArray(asFloat.size) { asFloat[it].toInt() }
    }

    override suspend fun release() {
        withContext(engineDispatcher) {
            releaseInternal()
        }
        engineDispatcher.close()
    }

    private fun releaseInternal() {
        inputBuffers.forEach { runCatching { it.close() } }
        outputBuffers.forEach { runCatching { it.close() } }
        inputBuffers = emptyList()
        outputBuffers = emptyList()
        runCatching { compiledModel?.close() }
        compiledModel = null
        runCatching { env?.close() }
        env = null
    }
}
