package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette - Tactile Acoustic Studio (Warm Alabaster & Signal Coral)
val StudioPaper = Color(0xFFF7F5F0)
val StudioCard = Color(0xFFFFFFFF)
val StudioSurfaceMuted = Color(0xFFEDEAE2)
val StudioSurfaceHigh = Color(0xFFE4E0D5)
val StudioOutline = Color(0xFFD6D1C4)
val StudioOutlineSubtle = Color(0xFFE7E3D8)
val StudioInk = Color(0xFF17181C)
val StudioSlate = Color(0xFF5A5F6A)

val SignalCoral = Color(0xFFE05A2B)
val SignalCoralContainer = Color(0xFFFCE6DE)
val SignalCoralDarkText = Color(0xFF6B2108)

val AcousticTeal = Color(0xFF0E7C7B)
val AcousticTealContainer = Color(0xFFD8F3F0)
val AcousticTealDarkText = Color(0xFF084241)

val TelemetryBlue = Color(0xFF2563EB)
val TelemetryBlueContainer = Color(0xFFDBEAFE)
val TelemetryBlueDarkText = Color(0xFF1E3A8A)

val AlertRed = Color(0xFFDC2626)
val AlertRedContainer = Color(0xFFFEE2E2)

// Dark Palette - Studio Night Console
val DarkStudioBg = Color(0xFF101216)
val DarkStudioCard = Color(0xFF191C22)
val DarkStudioSurfaceMuted = Color(0xFF22262E)
val DarkStudioSurfaceHigh = Color(0xFF2B303A)
val DarkStudioOutline = Color(0xFF343A46)
val DarkStudioInk = Color(0xFFF2EFE9)
val DarkStudioSlate = Color(0xFF9CA3AF)

val DarkSignalCoral = Color(0xFFFF7A4D)
val DarkSignalCoralContainer = Color(0xFF4B2112)
val DarkAcousticTeal = Color(0xFF2DD4BF)
val DarkAcousticTealContainer = Color(0xFF0F3B37)
val DarkTelemetryBlue = Color(0xFF60A5FA)
val DarkTelemetryBlueContainer = Color(0xFF172B4D)
