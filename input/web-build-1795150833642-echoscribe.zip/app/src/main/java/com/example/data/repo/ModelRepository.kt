package com.example.data.repo

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.db.EchoScribeDao
import com.example.data.db.ImportedModelEntity
import com.example.data.db.ModelFormat
import com.example.whisper.ModelInspector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

sealed class ImportResult {
    data class Success(val model: ImportedModelEntity, val warning: String? = null) : ImportResult()
    data class Error(val message: String) : ImportResult()
}

class ModelRepository(
    private val context: Context,
    private val dao: EchoScribeDao,
) {
    val models: Flow<List<ImportedModelEntity>> = dao.observeModels()
    val selectedModel: Flow<ImportedModelEntity?> = dao.observeSelectedModel()

    suspend fun getSelectedModel(): ImportedModelEntity? = dao.getSelectedModel()

    suspend fun importModelFromUri(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            val fileName = resolveFileName(uri) ?: "whisper_model.tflite"
            val lower = fileName.lowercase()
            val supportedExt = lower.endsWith(".tflite") ||
                lower.endsWith(".onnx") ||
                lower.endsWith(".bin") ||
                lower.endsWith(".gguf")

            if (!supportedExt) {
                return@withContext ImportResult.Error(
                    "Unsupported file '$fileName'. Please pick a .tflite or .onnx Whisper model file."
                )
            }

            val modelId = UUID.randomUUID().toString()
            val modelsDir = File(context.filesDir, "models/$modelId").apply { mkdirs() }
            val destFile = File(modelsDir, fileName)

            copyUriToFile(uri, destFile)
            if (destFile.length() < 1024L) {
                destFile.deleteRecursively()
                return@withContext ImportResult.Error("Selected file appears empty or unreadable.")
            }

            val inspected = ModelInspector.inspect(destFile, fileName)
            val cleanName = fileName
                .substringBeforeLast('.')
                .replace('_', ' ')
                .replace('-', ' ')
                .replaceFirstChar { it.uppercase() }

            val currentlySelected = dao.getSelectedModel()
            val shouldSelect = currentlySelected == null &&
                inspected.format != ModelFormat.GGML_UNSUPPORTED_RUNTIME

            val entity = ImportedModelEntity(
                id = modelId,
                name = cleanName,
                fileName = fileName,
                format = inspected.format.name,
                primaryPath = destFile.absolutePath,
                fileSizeBytes = destFile.length(),
                sizeTier = inspected.sizeTier,
                multilingual = inspected.multilingual,
                inputShapeSummary = inspected.inputShapeSummary,
                isSelected = shouldSelect,
            )

            dao.upsertModel(entity)
            ImportResult.Success(entity, inspected.warningMessage)
        } catch (e: Exception) {
            ImportResult.Error("Failed to import model: ${e.message ?: "Unknown I/O error"}")
        }
    }

    suspend fun attachVocabToModel(modelId: String, uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            val model = dao.getModelById(modelId)
                ?: return@withContext ImportResult.Error("Model not found.")
            val fileName = resolveFileName(uri) ?: "vocab.bin"
            val modelDir = File(context.filesDir, "models/$modelId").apply { mkdirs() }
            val destFile = File(modelDir, "vocab_$fileName")
            copyUriToFile(uri, destFile)

            val updated = model.copy(
                vocabPath = destFile.absolutePath,
                vocabFileName = fileName,
            )
            dao.upsertModel(updated)
            ImportResult.Success(updated)
        } catch (e: Exception) {
            ImportResult.Error("Failed to attach vocabulary: ${e.message}")
        }
    }

    suspend fun attachDecoderOnnxToModel(modelId: String, uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            val model = dao.getModelById(modelId)
                ?: return@withContext ImportResult.Error("Model not found.")
            val fileName = resolveFileName(uri) ?: "decoder.onnx"
            if (!fileName.lowercase().endsWith(".onnx")) {
                return@withContext ImportResult.Error("Decoder must be an .onnx file.")
            }
            val modelDir = File(context.filesDir, "models/$modelId").apply { mkdirs() }
            val destFile = File(modelDir, "decoder_$fileName")
            copyUriToFile(uri, destFile)

            val updated = model.copy(
                format = ModelFormat.ONNX_ENCODER_DECODER.name,
                decoderPath = destFile.absolutePath,
                inputShapeSummary = "ONNX Encoder + Decoder • CPU ExecutionProvider",
            )
            dao.upsertModel(updated)
            ImportResult.Success(updated)
        } catch (e: Exception) {
            ImportResult.Error("Failed to attach decoder ONNX: ${e.message}")
        }
    }

    suspend fun selectModel(modelId: String) {
        dao.selectModel(modelId)
    }

    suspend fun deleteModel(modelId: String) = withContext(Dispatchers.IO) {
        val model = dao.getModelById(modelId)
        dao.deleteModel(modelId)
        File(context.filesDir, "models/$modelId").deleteRecursively()
        if (model?.isSelected == true) {
            // Select another runnable model if available
            val remaining = dao.getSelectedModel()
            if (remaining == null) {
                // Handled reactively by UI / next import
            }
        }
    }

    private fun resolveFileName(uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return cursor.getString(idx)
                }
            }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun copyUriToFile(uri: Uri, dest: File) {
        val input = context.contentResolver.openInputStream(uri)
            ?: error("Could not open input stream for selected file.")
        input.use { rawIn ->
            BufferedInputStream(rawIn, 64 * 1024).use { bis ->
                BufferedOutputStream(FileOutputStream(dest), 64 * 1024).use { bos ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = bis.read(buffer)
                        if (read <= 0) break
                        bos.write(buffer, 0, read)
                    }
                    bos.flush()
                }
            }
        }
    }
}
