package com.example.whisper

import com.example.data.db.AudioChunkEntity
import java.util.Locale

/**
 * Connects individual transcribed audio chunks into one clean, continuous transcript,
 * deduplicating overlapping boundary words created by chunk overlap padding.
 */
object TranscriptStitcher {

    fun stitchChunks(chunks: List<AudioChunkEntity>): String {
        val completed = chunks
            .sortedBy { it.chunkIndex }
            .map { it.rawText.trim() }
            .filter { it.isNotEmpty() }

        if (completed.isEmpty()) return ""
        var accumulated = completed.first()

        for (i in 1 until completed.size) {
            accumulated = mergeWithOverlap(accumulated, completed[i])
        }
        return accumulated
    }

    fun mergeWithOverlap(existing: String, nextChunk: String): String {
        val cleanExisting = existing.trim()
        val cleanNext = nextChunk.trim()
        if (cleanExisting.isEmpty()) return cleanNext
        if (cleanNext.isEmpty()) return cleanExisting

        val existingWords = cleanExisting.split(Regex("\\s+"))
        val nextWords = cleanNext.split(Regex("\\s+"))

        val maxOverlap = minOf(14, existingWords.size, nextWords.size)
        var matchedWordCount = 0

        for (k in maxOverlap downTo 1) {
            var allMatch = true
            for (j in 0 until k) {
                val w1 = normalizeWord(existingWords[existingWords.size - k + j])
                val w2 = normalizeWord(nextWords[j])
                if (w1 != w2) {
                    allMatch = false
                    break
                }
            }
            if (allMatch) {
                matchedWordCount = k
                break
            }
        }

        return if (matchedWordCount > 0) {
            val remaining = nextWords.drop(matchedWordCount)
            if (remaining.isEmpty()) cleanExisting else "$cleanExisting ${remaining.joinToString(" ")}"
        } else {
            "$cleanExisting $cleanNext"
        }
    }

    private fun normalizeWord(word: String): String {
        return word.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]"), "")
    }

    fun formatAsSrt(chunks: List<AudioChunkEntity>): String {
        val sb = StringBuilder()
        var index = 1
        chunks.sortedBy { it.chunkIndex }.forEach { chunk ->
            val text = chunk.rawText.trim()
            if (text.isNotEmpty()) {
                sb.append(index++).append('\n')
                sb.append(formatSrtTime(chunk.startMs))
                    .append(" --> ")
                    .append(formatSrtTime(chunk.endMs))
                    .append('\n')
                sb.append(text).append("\n\n")
            }
        }
        return sb.toString().trimEnd()
    }

    fun formatAsVtt(chunks: List<AudioChunkEntity>): String {
        val sb = StringBuilder("WEBVTT\n\n")
        chunks.sortedBy { it.chunkIndex }.forEach { chunk ->
            val text = chunk.rawText.trim()
            if (text.isNotEmpty()) {
                sb.append(formatVttTime(chunk.startMs))
                    .append(" --> ")
                    .append(formatVttTime(chunk.endMs))
                    .append('\n')
                sb.append(text).append("\n\n")
            }
        }
        return sb.toString().trimEnd()
    }

    private fun formatSrtTime(ms: Long): String {
        val totalSec = ms / 1000
        val millis = ms % 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    private fun formatVttTime(ms: Long): String {
        val totalSec = ms / 1000
        val millis = ms % 1000
        val hours = totalSec / 3600
        val minutes = (totalSec % 3600) / 60
        val seconds = totalSec % 60
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", hours, minutes, seconds, millis)
    }
}
