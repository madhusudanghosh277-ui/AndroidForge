package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import androidx.core.net.toUri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

data class RecorderState(
    val isRecording: Boolean = false,
    val elapsedMs: Long = 0L,
    val amplitude: Float = 0f,
    val recordedFileUri: Uri? = null,
    val errorMessage: String? = null,
)

class AudioRecorderManager(private val context: Context) {
    private val _state = MutableStateFlow(RecorderState())
    val state: StateFlow<RecorderState> = _state.asStateFlow()

    private var recordJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var activeFile: File? = null

    @SuppressLint("MissingPermission")
    fun startRecording(scope: CoroutineScope) {
        if (_state.value.isRecording) return
        val dir = File(context.filesDir, "recordings").apply { mkdirs() }
        val file = File(dir, "recording_${System.currentTimeMillis()}.wav")
        activeFile = file

        val sampleRate = 16000
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        ).coerceAtLeast(4096)

        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf * 2,
            )
        } catch (e: Exception) {
            _state.value = RecorderState(errorMessage = "Could not initialize microphone: ${e.message}")
            return
        }

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            _state.value = RecorderState(errorMessage = "Microphone initialization failed.")
            return
        }

        audioRecord = recorder
        recorder.startRecording()
        val startTime = System.currentTimeMillis()
        _state.value = RecorderState(isRecording = true, elapsedMs = 0L, amplitude = 0f)

        recordJob = scope.launch(Dispatchers.IO) {
            var totalBytesWritten = 0L
            try {
                BufferedOutputStream(FileOutputStream(file), 16 * 1024).use { out ->
                    // Reserve 44-byte WAV header
                    out.write(ByteArray(44))
                    val shortBuf = ShortArray(1600) // 100ms chunks
                    val byteBuf = ByteArray(shortBuf.size * 2)

                    while (isActive && _state.value.isRecording) {
                        val read = recorder.read(shortBuf, 0, shortBuf.size)
                        if (read > 0) {
                            var sumSq = 0.0
                            for (i in 0 until read) {
                                val s = shortBuf[i].toInt()
                                byteBuf[i * 2] = (s and 0xFF).toByte()
                                byteBuf[i * 2 + 1] = ((s ushr 8) and 0xFF).toByte()
                                val norm = s / 32768.0
                                sumSq += norm * norm
                            }
                            out.write(byteBuf, 0, read * 2)
                            totalBytesWritten += read * 2L
                            val rms = sqrt(sumSq / read).toFloat()
                            _state.value = _state.value.copy(
                                elapsedMs = System.currentTimeMillis() - startTime,
                                amplitude = (rms * 4f).coerceIn(0f, 1f),
                            )
                        }
                    }
                    out.flush()
                }
                writeWavHeader(file, totalBytesWritten, sampleRate, 1, 16)
                _state.value = _state.value.copy(
                    isRecording = false,
                    amplitude = 0f,
                    recordedFileUri = file.toUri(),
                )
            } catch (e: Exception) {
                _state.value = RecorderState(
                    isRecording = false,
                    errorMessage = "Recording error: ${e.message}",
                )
            } finally {
                runCatching { recorder.stop() }
                runCatching { recorder.release() }
                audioRecord = null
            }
        }
    }

    fun stopRecording() {
        if (!_state.value.isRecording) return
        _state.value = _state.value.copy(isRecording = false)
    }

    fun clearRecordedUri() {
        _state.value = _state.value.copy(recordedFileUri = null, errorMessage = null)
    }

    private fun writeWavHeader(
        file: File,
        pcmDataSize: Long,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int,
    ) {
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val blockAlign = channels * bitsPerSample / 8
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt((36 + pcmDataSize).toInt())
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16) // PCM chunk size
            putShort(1) // PCM format
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort(blockAlign.toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray())
            putInt(pcmDataSize.toInt())
        }.array()

        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(0)
            raf.write(header)
        }
    }
}
