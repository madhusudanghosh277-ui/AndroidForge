package com.example.whisper

import com.example.data.db.ImportedModelEntity
import com.example.data.db.ModelFormat

data class WhisperChunkResult(
    val text: String,
    val inferenceMs: Long,
    val tokenCount: Int,
)

interface WhisperEngine {
    suspend fun load(model: ImportedModelEntity, cpuThreads: Int)
    suspend fun transcribeChunk(
        pcm16: ShortArray,
        languageCode: String,
        translateToEnglish: Boolean,
    ): WhisperChunkResult

    suspend fun release()
}

object WhisperEngineFactory {
    fun create(format: ModelFormat): WhisperEngine {
        return when (format) {
            ModelFormat.TFLITE -> LiteRtWhisperEngine()
            ModelFormat.ONNX_SINGLE,
            ModelFormat.ONNX_ENCODER_DECODER -> OnnxWhisperEngine()
            ModelFormat.GGML_UNSUPPORTED_RUNTIME -> {
                throw IllegalStateException(
                    "GGML .bin files require a native whisper.cpp binary not bundled for all CPU ABIs. " +
                        "Please import a .tflite (LiteRT) or .onnx Whisper model instead."
                )
            }
        }
    }
}
