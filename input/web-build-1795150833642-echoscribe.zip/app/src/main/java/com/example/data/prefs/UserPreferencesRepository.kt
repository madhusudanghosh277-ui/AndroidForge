package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "echoscribe_settings")

data class TranscriptionSettings(
    val cpuThreads: Int = defaultCpuThreadCount(),
    val chunkDurationSec: Int = 30,
    val overlapSec: Int = 2,
    val vadSplitEnabled: Boolean = true,
    val languageCode: String = "en",
    val translateToEnglish: Boolean = false,
) {
    companion object {
        fun defaultCpuThreadCount(): Int {
            val cores = Runtime.getRuntime().availableProcessors()
            return (cores / 2).coerceIn(2, 4)
        }
    }
}

class UserPreferencesRepository(private val context: Context) {
    private object Keys {
        val CPU_THREADS = intPreferencesKey("cpu_threads")
        val CHUNK_DURATION_SEC = intPreferencesKey("chunk_duration_sec")
        val OVERLAP_SEC = intPreferencesKey("overlap_sec")
        val VAD_SPLIT_ENABLED = booleanPreferencesKey("vad_split_enabled")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val TRANSLATE_TO_ENGLISH = booleanPreferencesKey("translate_to_english")
    }

    val settingsFlow: Flow<TranscriptionSettings> = context.dataStore.data.map { prefs ->
        TranscriptionSettings(
            cpuThreads = prefs[Keys.CPU_THREADS] ?: TranscriptionSettings.defaultCpuThreadCount(),
            chunkDurationSec = prefs[Keys.CHUNK_DURATION_SEC] ?: 30,
            overlapSec = prefs[Keys.OVERLAP_SEC] ?: 2,
            vadSplitEnabled = prefs[Keys.VAD_SPLIT_ENABLED] ?: true,
            languageCode = prefs[Keys.LANGUAGE_CODE] ?: "en",
            translateToEnglish = prefs[Keys.TRANSLATE_TO_ENGLISH] ?: false,
        )
    }

    suspend fun setCpuThreads(threads: Int) {
        context.dataStore.edit { it[Keys.CPU_THREADS] = threads.coerceIn(1, 8) }
    }

    suspend fun setChunkDurationSec(seconds: Int) {
        context.dataStore.edit { it[Keys.CHUNK_DURATION_SEC] = seconds.coerceIn(10, 30) }
    }

    suspend fun setOverlapSec(seconds: Int) {
        context.dataStore.edit { it[Keys.OVERLAP_SEC] = seconds.coerceIn(0, 5) }
    }

    suspend fun setVadSplitEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VAD_SPLIT_ENABLED] = enabled }
    }

    suspend fun setLanguageCode(code: String) {
        context.dataStore.edit { it[Keys.LANGUAGE_CODE] = code }
    }

    suspend fun setTranslateToEnglish(translate: Boolean) {
        context.dataStore.edit { it[Keys.TRANSLATE_TO_ENGLISH] = translate }
    }
}
