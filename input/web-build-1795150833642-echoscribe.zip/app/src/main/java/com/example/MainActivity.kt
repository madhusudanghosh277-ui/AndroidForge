package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.EchoScribeViewModel
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ModelsScreen
import com.example.ui.screens.StudioScreen
import com.example.ui.screens.TranscriptDetailScreen
import com.example.ui.theme.EchoScribeTheme
import kotlinx.coroutines.launch

private const val ROUTE_STUDIO = "studio"
private const val ROUTE_LIBRARY = "library"
private const val ROUTE_MODELS = "models"
private const val ROUTE_JOB_DETAIL = "job_detail/{jobId}"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EchoScribeTheme {
                EchoScribeApp()
            }
        }
    }
}

@Composable
fun EchoScribeApp(viewModel: EchoScribeViewModel = viewModel()) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val models by viewModel.models.collectAsStateWithLifecycle()
    val selectedModel by viewModel.selectedModel.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val jobs by viewModel.jobs.collectAsStateWithLifecycle()
    val activeJob by viewModel.activeJob.collectAsStateWithLifecycle()
    val activeChunks by viewModel.activeJobChunks.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val stagedAudio by viewModel.stagedAudio.collectAsStateWithLifecycle()
    val isInspectingAudio by viewModel.isInspectingAudio.collectAsStateWithLifecycle()
    val isImportingModel by viewModel.isImportingModel.collectAsStateWithLifecycle()
    val recorderState by viewModel.recorderState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.snackbarMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // SAF File Pickers (zero storage permissions required)
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let { viewModel.stageAudioUri(it) } },
    )

    val modelPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri -> uri?.let { viewModel.importModelFile(it) } },
    )

    var pendingModelIdForAttachment by remember { mutableStateOf<String?>(null) }

    val vocabPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            val targetId = pendingModelIdForAttachment
            pendingModelIdForAttachment = null
            if (uri != null && targetId != null) {
                viewModel.attachVocabFile(targetId, uri)
            }
        },
    )

    val decoderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            val targetId = pendingModelIdForAttachment
            pendingModelIdForAttachment = null
            if (uri != null && targetId != null) {
                viewModel.attachDecoderFile(targetId, uri)
            }
        },
    )

    // Runtime Permission Launchers
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            if (granted) {
                viewModel.startRecording()
            } else {
                scope.launch {
                    snackbarHostState.showSnackbar("Microphone permission is needed to record audio.")
                }
            }
        },
    )

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { _ ->
            viewModel.startTranscription()
        },
    )

    fun handleStartTranscription() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        viewModel.startTranscription()
    }

    fun handleToggleRecording() {
        if (recorderState.isRecording) {
            viewModel.stopRecording()
        } else {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO,
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) {
                viewModel.startRecording()
            } else {
                recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showTopLevelNav = currentRoute == ROUTE_STUDIO ||
        currentRoute == ROUTE_LIBRARY ||
        currentRoute == ROUTE_MODELS

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (showTopLevelNav && !useRail) {
                    NavigationBar {
                        NavigationBarItem(
                            selected = currentRoute == ROUTE_STUDIO,
                            onClick = {
                                navController.navigate(ROUTE_STUDIO) {
                                    popUpTo(ROUTE_STUDIO) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (currentRoute == ROUTE_STUDIO) Icons.Rounded.GraphicEq else Icons.Outlined.GraphicEq,
                                    contentDescription = "Transcribe",
                                )
                            },
                            label = { Text("Transcribe") },
                            modifier = Modifier.testTag("nav_studio"),
                        )
                        NavigationBarItem(
                            selected = currentRoute == ROUTE_LIBRARY,
                            onClick = {
                                navController.navigate(ROUTE_LIBRARY) {
                                    popUpTo(ROUTE_STUDIO) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (currentRoute == ROUTE_LIBRARY) Icons.Rounded.Description else Icons.Outlined.Description,
                                    contentDescription = "Transcripts",
                                )
                            },
                            label = { Text("Transcripts") },
                            modifier = Modifier.testTag("nav_library"),
                        )
                        NavigationBarItem(
                            selected = currentRoute == ROUTE_MODELS,
                            onClick = {
                                navController.navigate(ROUTE_MODELS) {
                                    popUpTo(ROUTE_STUDIO) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (currentRoute == ROUTE_MODELS) Icons.Rounded.Memory else Icons.Outlined.Memory,
                                    contentDescription = "Models",
                                )
                            },
                            label = { Text("Models") },
                            modifier = Modifier.testTag("nav_models"),
                        )
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (showTopLevelNav && useRail) {
                    NavigationRail {
                        NavigationRailItem(
                            selected = currentRoute == ROUTE_STUDIO,
                            onClick = {
                                navController.navigate(ROUTE_STUDIO) {
                                    popUpTo(ROUTE_STUDIO) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (currentRoute == ROUTE_STUDIO) Icons.Rounded.GraphicEq else Icons.Outlined.GraphicEq,
                                    contentDescription = "Transcribe",
                                )
                            },
                            label = { Text("Transcribe") },
                        )
                        NavigationRailItem(
                            selected = currentRoute == ROUTE_LIBRARY,
                            onClick = {
                                navController.navigate(ROUTE_LIBRARY) {
                                    popUpTo(ROUTE_STUDIO) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (currentRoute == ROUTE_LIBRARY) Icons.Rounded.Description else Icons.Outlined.Description,
                                    contentDescription = "Transcripts",
                                )
                            },
                            label = { Text("Transcripts") },
                        )
                        NavigationRailItem(
                            selected = currentRoute == ROUTE_MODELS,
                            onClick = {
                                navController.navigate(ROUTE_MODELS) {
                                    popUpTo(ROUTE_STUDIO) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    if (currentRoute == ROUTE_MODELS) Icons.Rounded.Memory else Icons.Outlined.Memory,
                                    contentDescription = "Models",
                                )
                            },
                            label = { Text("Models") },
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_STUDIO,
                    ) {
                        composable(ROUTE_STUDIO) {
                            StudioScreen(
                                selectedModel = selectedModel,
                                settings = settings,
                                stagedAudio = stagedAudio,
                                isInspectingAudio = isInspectingAudio,
                                recorderState = recorderState,
                                activeJob = activeJob,
                                activeChunks = activeChunks,
                                telemetry = telemetry,
                                recentJobs = jobs,
                                onPickAudioClick = {
                                    audioPickerLauncher.launch(arrayOf("audio/*", "video/*"))
                                },
                                onToggleRecordClick = ::handleToggleRecording,
                                onOpenModelsTab = {
                                    navController.navigate(ROUTE_MODELS) {
                                        popUpTo(ROUTE_STUDIO) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                onStagedTitleChange = viewModel::updateStagedTitle,
                                onClearStagedAudio = viewModel::clearStagedAudio,
                                onStartTranscription = ::handleStartTranscription,
                                onPauseActiveJob = viewModel::pauseActiveJob,
                                onCancelActiveJob = viewModel::cancelActiveJob,
                                onOpenJobDetail = { jobId ->
                                    navController.navigate("job_detail/$jobId")
                                },
                                onCpuThreadsChange = viewModel::setCpuThreads,
                                onChunkDurationChange = viewModel::setChunkDurationSec,
                                onOverlapChange = viewModel::setOverlapSec,
                                onVadSplitChange = viewModel::setVadSplitEnabled,
                                onLanguageChange = viewModel::setLanguageCode,
                                onTranslateChange = viewModel::setTranslateToEnglish,
                            )
                        }

                        composable(ROUTE_LIBRARY) {
                            LibraryScreen(
                                jobs = jobs,
                                onOpenJobDetail = { jobId ->
                                    navController.navigate("job_detail/$jobId")
                                },
                                onResumeJob = { jobId -> viewModel.resumeJob(jobId) },
                                onDeleteJob = viewModel::deleteJob,
                            )
                        }

                        composable(ROUTE_MODELS) {
                            ModelsScreen(
                                models = models,
                                isImporting = isImportingModel,
                                onImportModelClick = {
                                    modelPickerLauncher.launch(arrayOf("*/*"))
                                },
                                onSelectModel = viewModel::selectModel,
                                onAttachVocabClick = { modelId ->
                                    pendingModelIdForAttachment = modelId
                                    vocabPickerLauncher.launch(arrayOf("*/*"))
                                },
                                onAttachDecoderClick = { modelId ->
                                    pendingModelIdForAttachment = modelId
                                    decoderPickerLauncher.launch(arrayOf("*/*"))
                                },
                                onDeleteModel = viewModel::deleteModel,
                            )
                        }

                        composable(
                            route = ROUTE_JOB_DETAIL,
                            arguments = listOf(navArgument("jobId") { type = NavType.StringType }),
                        ) { entry ->
                            val jobId = entry.arguments?.getString("jobId").orEmpty()
                            val detailJob by viewModel.observeJob(jobId).collectAsStateWithLifecycle(initialValue = null)
                            val detailChunks by viewModel.observeChunks(jobId).collectAsStateWithLifecycle(initialValue = emptyList())

                            TranscriptDetailScreen(
                                job = detailJob,
                                chunks = detailChunks,
                                onBack = { navController.popBackStack() },
                                onResumeJob = { id -> viewModel.resumeJob(id) },
                                onRetryChunk = { id, chunkId -> viewModel.resumeJob(id, chunkId) },
                                onUpdateChunkText = viewModel::updateChunkText,
                                onBuildExport = viewModel::buildExportText,
                                onShowMessage = { msg ->
                                    scope.launch { snackbarHostState.showSnackbar(msg) }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}
