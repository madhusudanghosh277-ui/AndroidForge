package com.example

import com.example.audio.StreamingLinearResampler
import com.example.audio.WhisperAudioProcessor
import com.example.data.db.AudioChunkEntity
import com.example.data.db.ChunkStatus
import com.example.whisper.TranscriptStitcher
import com.example.whisper.WhisperTokenizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sin

class EchoScribePipelineTest {

    @Test
    fun stitchChunks_deduplicatesOverlapWordsCleanly() {
        val c0 = AudioChunkEntity(
            id = "1",
            jobId = "job1",
            chunkIndex = 0,
            startMs = 0L,
            endMs = 30_000L,
            pcmFilePath = "",
            status = ChunkStatus.COMPLETED.name,
            rawText = "Welcome to the local transcription studio where we process long audio",
        )
        val c1 = AudioChunkEntity(
            id = "2",
            jobId = "job1",
            chunkIndex = 1,
            startMs = 28_000L,
            endMs = 58_000L,
            pcmFilePath = "",
            status = ChunkStatus.COMPLETED.name,
            rawText = "process long audio files on mobile CPU.",
        )

        val stitched = TranscriptStitcher.stitchChunks(listOf(c1, c0))
        assertEquals(
            "Welcome to the local transcription studio where we process long audio files on mobile CPU.",
            stitched,
        )
    }

    @Test
    fun formatAsSrt_producesValidTimestamps() {
        val chunks = listOf(
            AudioChunkEntity(
                id = "1",
                jobId = "job1",
                chunkIndex = 0,
                startMs = 0L,
                endMs = 30_500L,
                pcmFilePath = "",
                status = ChunkStatus.COMPLETED.name,
                rawText = "First chunk text.",
            )
        )
        val srt = TranscriptStitcher.formatAsSrt(chunks)
        assertTrue(srt.contains("00:00:00,000 --> 00:00:30,500"))
        assertTrue(srt.contains("First chunk text."))
    }

    @Test
    fun streamingResampler_downsamples48kTo16k() {
        val resampler = StreamingLinearResampler(48000, 16000)
        val input = FloatArray(4800) { i -> sin(i * 0.05f) * 0.5f }
        val out = resampler.resample(input)
        assertTrue(out.size in 1598..1602)
    }

    @Test
    fun logMelSpectrogram_outputsExpectedWhisperShape() {
        val pcm = ShortArray(16000) { i -> (sin(i * 0.1) * 12000).toInt().toShort() }
        val mel = WhisperAudioProcessor.computeLogMelSpectrogram(pcm)
        assertEquals(WhisperAudioProcessor.N_MELS * WhisperAudioProcessor.N_FRAMES, mel.size)
        assertTrue(mel.all { it.isFinite() })
    }

    @Test
    fun tokenizer_skipsSpecialTokensAndDecodesMap() {
        val tokenizer = WhisperTokenizer(
            idToToken = mapOf(
                100 to "Hello",
                101 to " world",
            ),
            vocabSize = 2,
        )
        val decoded = tokenizer.decodeTokens(
            intArrayOf(
                WhisperTokenizer.TOKEN_SOT,
                50259,
                WhisperTokenizer.TOKEN_TRANSCRIBE,
                100,
                101,
                WhisperTokenizer.TOKEN_EOT,
                100,
            )
        )
        assertEquals("Hello world", decoded)
    }
}
